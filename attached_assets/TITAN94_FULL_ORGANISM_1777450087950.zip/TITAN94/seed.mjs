// seed.mjs — run: node seed.mjs
import { createRequire } from "module";
const require = createRequire(import.meta.url);
const pg = require("pg");
const { Pool } = pg;
const pool = new Pool({ connectionString: process.env.DATABASE_URL });
const client = await pool.connect();

await client.query(`
  INSERT INTO vulnerabilities (id, external_id, title, description, severity, protocol, contract_address, tvl_at_risk, status, category)
  VALUES
    (gen_random_uuid()::text, 'vuln-001', 'Reentrancy in DeDust', 'Recursive call before state update allows drain', 'critical', 'DeDust', 'EQA1B2C3D4E5', '4200000', 'active', 'reentrancy'),
    (gen_random_uuid()::text, 'vuln-002', 'LP Overflow in STON.fi', 'Unchecked arithmetic in LP minting', 'high', 'STON.fi', 'EQB2C3D4E5F6', '1800000', 'active', 'overflow'),
    (gen_random_uuid()::text, 'vuln-003', 'HoneyPot Token SCAM', 'Hidden sell restriction in transfer()', 'high', 'Unknown', 'EQC3D4E5F6G7', '340000', 'active', 'honeypot'),
    (gen_random_uuid()::text, 'vuln-004', 'Flash Loan Oracle Attack', 'Megaton price feed can be manipulated', 'critical', 'Megaton', 'EQD4E5F6G7H8', '8900000', 'active', 'oracle')
  ON CONFLICT (external_id) DO NOTHING
`);

await client.query(`
  INSERT INTO knowledge (id, external_id, category, pattern, description, confidence, occurrences, source)
  VALUES
    (gen_random_uuid()::text, 'k-001', 'reentrancy', 'recursive_call_before_state_update', 'State not updated before external call', '0.97', 23, 'ai_scan'),
    (gen_random_uuid()::text, 'k-002', 'honeypot', 'hidden_transfer_restriction', 'Transfer secretly restricts selling for non-owners', '0.95', 41, 'ai_scan'),
    (gen_random_uuid()::text, 'k-003', 'arbitrage', 'cross_dex_price_gap_2pct', 'Price gap > 2% between DEXes = arbitrage opportunity', '0.91', 156, 'ai_scan'),
    (gen_random_uuid()::text, 'k-004', 'oracle', 'flash_loan_price_manipulation', 'Single-block price manipulation via flash loan', '0.93', 18, 'ai_scan')
  ON CONFLICT (pattern) DO NOTHING
`);

await client.query(`
  INSERT INTO competitors (id, external_id, name, description, tvl, chain, threat_level)
  VALUES
    (gen_random_uuid()::text, 'comp-001', 'CertiK', 'Leading smart contract audit firm', '2.1B', 'Multi', 'low'),
    (gen_random_uuid()::text, 'comp-002', 'SlowMist', 'Blockchain security firm', '850M', 'Multi', 'low'),
    (gen_random_uuid()::text, 'comp-003', 'PeckShield', 'Smart contract audit + monitoring', '620M', 'Multi', 'medium')
  ON CONFLICT (external_id) DO NOTHING
`);

console.log("✅ TITAN-94 seed complete");
client.release();
await pool.end();
