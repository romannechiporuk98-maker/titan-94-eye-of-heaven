# TITAN-94 «ОКО НЕБЕСНЕ» — MASTER DEPLOY GUIDE
> Version: 3.2.0-OMNIPOTENT | Owner: @Cryptoagentton | DEI GRATIA

---

## 🏗️ АРХІТЕКТУРА

```
TITAN-94/
├── artifacts/
│   ├── api-server/          ← Express 5 + TypeScript (port 8080)
│   │   └── src/
│   │       ├── index.ts          ← entry, startHeartbeat()
│   │       ├── app.ts            ← Express + all routes
│   │       ├── services/
│   │       │   ├── heartbeat.ts  ← SCAN/HEAL/LEARN/FINANCE cycles
│   │       │   ├── gemini.ts     ← Gemini 2.5 Pro/Flash AI
│   │       │   ├── ton.ts        ← TON Center API
│   │       │   └── db.ts         ← Drizzle ORM connection
│   │       ├── middlewares/
│   │       │   └── telegram-auth.ts  ← HMAC-SHA256
│   │       └── routes/           ← 21 endpoints
│   └── titan-dashboard/     ← React 18 + Vite (port 5000)
│       └── src/
│           ├── App.tsx           ← Router + TonConnect + QueryClient
│           ├── pages/            ← 8 pages
│           └── components/       ← layout, mobile-layout, ui
├── lib/
│   └── db/src/schema/index.ts   ← Drizzle schema (8 tables)
├── bot/
│   └── main.py                  ← Telegram Bot (aiogram 3, 3 langs)
├── seed.mjs                     ← Initial DB data
└── ecosystem.config.cjs         ← PM2 production
```

---

## 🔐 SECRETS (Replit → Tools → Secrets)

| Key | Source | Required |
|-----|--------|----------|
| `DATABASE_URL` | Replit → Database → PostgreSQL | ✅ CRITICAL |
| `TELEGRAM_BOT_TOKEN` | @BotFather → /newbot | ✅ CRITICAL |
| `GEMINI_API_KEY` | aistudio.google.com | ✅ CRITICAL |
| `ADMIN_TELEGRAM_ID` | Your Telegram ID = `7255058720` | ✅ |
| `TON_API_KEY` | toncenter.com | ⚡ Optional |
| `SESSION_SECRET` | Any 32+ char string | ⚡ Optional |

---

## 🚀 DEPLOY (Replit)

```bash
# 1. Upload Titan-Build-Manager.zip → Replit Files → Unzip
# 2. Install deps
pnpm install

# 3. PostgreSQL: Replit → Database → Add PostgreSQL
# 4. Add Secrets (see above)

# 5. Push DB schema
pnpm --filter @workspace/db run push

# 6. Seed initial data
node seed.mjs

# 7. Setup Workflows:
#    Workflow 1 — API Server:
#      Command: PORT=8080 pnpm --filter @workspace/api-server run dev
#      Port: 8080, Output: console
#
#    Workflow 2 — Dashboard:
#      Command: PORT=5000 BASE_PATH=/ pnpm --filter @workspace/titan-dashboard run dev
#      Port: 5000, Output: webview

# 8. Telegram bot (separate shell):
pip install -r bot/requirements.txt
python bot/main.py
```

---

## 💓 HEARTBEAT CYCLES

| Cycle | Every | Action |
|-------|-------|--------|
| 👁️ SCAN | 3 min | TON masterchain check, log anomalies |
| ⚡ HEAL | 5 min | Auto-resolve threats >24h, log healing |
| 🧠 LEARN | 7 min | Generate AI pattern → knowledge base |
| 💰 FINANCE | 10 min | Expire old subs, log revenue stats |

---

## 🌐 API ENDPOINTS (21 total)

```
GET  /api/healthz
GET  /api/agent/stats
GET  /api/agent/cycles
POST /api/agent/scan
POST /api/analyze              ← Gemini AI analysis
POST /api/analyze/honeypot     ← HoneyPot detector
GET  /api/vulnerabilities
GET  /api/activity
GET  /api/competitors
GET  /api/ton/network
GET  /api/ton/wallet
GET  /api/ton/transactions
GET  /api/ton/contract/:addr
GET  /api/arbitrage/opportunities
GET  /api/monetization/plans
POST /api/monetization/subscribe
GET  /api/monetization/revenue
GET  /api/monetization/subscribers
GET  /api/monetization/status
POST /api/ai-evolution/trigger
GET  /api/ai-evolution/status
GET  /api/ai-evolution/knowledge
GET  /api/ecosystem/overview
POST /api/earn/trial/start
GET  /api/earn/trial/status
POST /api/earn/referral/register
GET  /api/earn/bounty
POST /api/webhook/ton-payment  ← 5 TON=PRO, 20 TON=ELITE
GET  /api/webhook/verify/:hash
```

---

## 💰 MONETIZATION

```
FREE  → 0 TON   — 5 scans/day, basic alerts
PRO   → 5 TON   — Unlimited, AI analysis, HoneyPot, real-time
ELITE → 20 TON  — Everything + Arbitrage, API, Whale alerts
```

Reserve Wallet: `UQC8seFr9xyA47kG2OIDRnKST8_1qPw3EN5pk6XlKLuNl-8v`

---

## 🤖 BOT COMMANDS

```
/start    — Activate + auto 72h PRO trial
/stats    — System statistics + cycle status
/scan     — Manual network scan
/analyze  — Gemini AI contract analysis
/honeypot — HoneyPot detector
/threats  — Top active threats
/wallet   — Reserve Fund balance
/arb      — Live DEX arbitrage signals
/earn     — Trial status + referrals + bounties
/heal     — Trigger healing cycle
/lang     — Change language (UA/EN/RU)
```

---

## 🔒 SENTINEL SECURITY

1. HMAC-SHA256 Telegram initData verification
2. Rate limit: 120 req/hour per IP
3. Anomaly detection: SQL/XSS/LFI regex blocking
4. TON multi-node fallback
5. Gemini Pro→Flash auto-fallback
6. Global error handler + self-healing

---

*TITAN-94 «ОКО НЕБЕСНЕ» — Solo Deo Subjectus · In Deo Infiniti Sumus*
