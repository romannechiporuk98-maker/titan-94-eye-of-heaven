module.exports = {
  apps: [
    {
      name: "TITAN-94-CORE",
      script: "./artifacts/api-server/dist/index.mjs",
      max_memory_restart: "1G",
      env: {
        NODE_ENV: "production",
        PORT: 8080
      },
      exp_backoff_restart_delay: 100,
      error_file: "./logs/titan-core-error.log",
      out_file: "./logs/titan-core-out.log",
      watch: false,
      autorestart: true
    },
    {
      name: "TITAN-94-DASHBOARD",
      script: "serve",
      args: "-s artifacts/titan-dashboard/dist -l 5000",
      env: { NODE_ENV: "production" },
      error_file: "./logs/titan-dash-error.log",
      out_file: "./logs/titan-dash-out.log"
    }
  ]
};
