import { pgTable, text, timestamp, integer, real, jsonb } from "drizzle-orm/pg-core";

export const vulnerabilities = pgTable("vulnerabilities", {
  id: text("id").primaryKey(),
  externalId: text("external_id").unique().notNull(),
  title: text("title").notNull(),
  description: text("description"),
  severity: text("severity").notNull(), // critical | high | medium | low
  protocol: text("protocol"),
  contractAddress: text("contract_address"),
  tvlAtRisk: text("tvl_at_risk"),
  status: text("status").default("active"), // active | resolved | investigating
  category: text("category"),
  healingPlan: text("healing_plan"),
  discoveredAt: timestamp("discovered_at").defaultNow(),
  updatedAt: timestamp("updated_at").defaultNow(),
});

export const activity = pgTable("activity", {
  id: text("id").primaryKey(),
  type: text("type").notNull(), // scan | heal | learn | finance | payment | manual_scan
  title: text("title").notNull(),
  message: text("message"),
  severity: text("severity").default("info"), // info | warning | error | critical
  metadata: jsonb("metadata"),
  createdAt: timestamp("created_at").defaultNow(),
});

export const competitors = pgTable("competitors", {
  id: text("id").primaryKey(),
  externalId: text("external_id").unique(),
  name: text("name").notNull(),
  description: text("description"),
  tvl: text("tvl"),
  chain: text("chain"),
  threatLevel: text("threat_level").default("low"),
  website: text("website"),
  riskScore: integer("risk_score").default(0),
  createdAt: timestamp("created_at").defaultNow(),
});

export const knowledge = pgTable("knowledge", {
  id: text("id").primaryKey(),
  externalId: text("external_id").unique(),
  category: text("category").notNull(),
  pattern: text("pattern").unique(),
  description: text("description"),
  confidence: text("confidence").default("0.90"),
  occurrences: integer("occurrences").default(1),
  source: text("source").default("ai_scan"),
  createdAt: timestamp("created_at").defaultNow(),
});

export const subscriptions = pgTable("subscriptions", {
  id: text("id").primaryKey(),
  externalId: text("external_id").unique().notNull(),
  planId: text("plan_id").notNull(),
  planName: text("plan_name"),
  telegramId: text("telegram_id"),
  username: text("username"),
  walletAddress: text("wallet_address"),
  amountPaidTon: real("amount_paid_ton").default(0),
  status: text("status").default("active"), // active | pending | expired | cancelled
  expiresAt: timestamp("expires_at"),
  referralCode: text("referral_code"),
  referredBy: text("referred_by"),
  trialAuditsUsed: integer("trial_audits_used").default(0),
  createdAt: timestamp("created_at").defaultNow(),
  updatedAt: timestamp("updated_at").defaultNow(),
});

export const referrals = pgTable("referrals", {
  id: text("id").primaryKey(),
  referrerTelegramId: text("referrer_telegram_id").notNull(),
  referredTelegramId: text("referred_telegram_id").notNull(),
  status: text("status").default("active"),
  bonusApplied: text("bonus_applied").default("false"),
  createdAt: timestamp("created_at").defaultNow(),
});

export const bounties = pgTable("bounties", {
  id: text("id").primaryKey(),
  vulnerabilityId: text("vulnerability_id"),
  reporter: text("reporter"),
  reward: real("reward"),
  titanShare: real("titan_share").default(0.1),
  reporterShare: real("reporter_share").default(0.9),
  status: text("status").default("open"),
  createdAt: timestamp("created_at").defaultNow(),
});

export const agentState = pgTable("agent_state", {
  id: text("id").primaryKey().default("singleton"),
  scanCycles: integer("scan_cycles").default(0),
  healCycles: integer("heal_cycles").default(0),
  learnCycles: integer("learn_cycles").default(0),
  financeCycles: integer("finance_cycles").default(0),
  aiAccuracy: real("ai_accuracy").default(0.94),
  threatsHealed: integer("threats_healed").default(0),
  updatedAt: timestamp("updated_at").defaultNow(),
});
