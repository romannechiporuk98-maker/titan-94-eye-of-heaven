"""
TITAN-94 «ОКО НЕБЕСНЕ» — Telegram Bot
aiogram 3 | 3 languages: UA / EN / RU
Commands: /start /stats /scan /analyze /honeypot /threats /market /wallet /trial /earn /arb /heal /lang
"""
import asyncio
import os
import json
import aiohttp
from aiogram import Bot, Dispatcher, types, F
from aiogram.filters import Command, CommandStart
from aiogram.types import InlineKeyboardMarkup, InlineKeyboardButton, WebAppInfo
from aiogram.utils.keyboard import InlineKeyboardBuilder

BOT_TOKEN = os.getenv("TELEGRAM_BOT_TOKEN", "")
API_URL = os.getenv("TITAN_API_URL", "http://localhost:8080/api")
MINI_APP_URL = os.getenv("TITAN_MINI_APP_URL", "https://titan94.replit.app")
ADMIN_ID = int(os.getenv("ADMIN_TELEGRAM_ID", "7255058720"))

bot = Bot(token=BOT_TOKEN)
dp = Dispatcher()

# ── i18n ──────────────────────────────────────────────────────
user_lang: dict[int, str] = {}

TEXTS = {
    "ua": {
        "welcome": "👁️ *TITAN-94 «ОКО НЕБЕСНЕ»* активовано\n\n🔰 Автономний AI-організм безпеки TON\n\n💎 Гаманець: `UQC8seFr9xyA47kG2OIDRnKST8_1qPw3EN5pk6XlKLuNl-8v`\n\n⚡ 72г PRO Trial активовано!",
        "choose_lang": "🌐 Оберіть мову / Choose language / Выберите язык:",
        "open_terminal": "◈ TITAN Terminal",
        "stats_title": "📊 *TITAN-94 Статистика*",
        "scan_ok": "👁️ Сканування запущено! Результати — в /threats",
        "no_address": "❌ Вкажіть адресу: /analyze EQ...",
        "analyzing": "🧠 Аналізую контракт... (Gemini AI)",
        "honeypot_analyzing": "🍯 Перевіряю на HoneyPot...",
        "threats_title": "🚨 *Активні загрози:*",
        "wallet_title": "💎 *Reserve Fund*",
        "earn_title": "💰 *EARN CENTER*\n\n🎯 Trial 72г PRO\n⚔️ Реферали 10+10\n🏆 Bounty Hunter",
        "arb_title": "📈 *DEX Арбітраж*",
        "heal_title": "⚡ *Healing цикл запущено*",
    },
    "en": {
        "welcome": "👁️ *TITAN-94 «SKY EYE»* activated\n\n🔰 Autonomous AI Security for TON blockchain\n\n💎 Wallet: `UQC8seFr9xyA47kG2OIDRnKST8_1qPw3EN5pk6XlKLuNl-8v`\n\n⚡ 72h PRO Trial activated!",
        "choose_lang": "🌐 Choose language:",
        "open_terminal": "◈ TITAN Terminal",
        "stats_title": "📊 *TITAN-94 Stats*",
        "scan_ok": "👁️ Scan launched! Check /threats for results",
        "no_address": "❌ Provide address: /analyze EQ...",
        "analyzing": "🧠 Analyzing contract... (Gemini AI)",
        "honeypot_analyzing": "🍯 Checking for HoneyPot...",
        "threats_title": "🚨 *Active Threats:*",
        "wallet_title": "💎 *Reserve Fund*",
        "earn_title": "💰 *EARN CENTER*\n\n🎯 72h PRO Trial\n⚔️ Referral 10+10\n🏆 Bounty Hunter",
        "arb_title": "📈 *DEX Arbitrage*",
        "heal_title": "⚡ *Healing cycle triggered*",
    },
    "ru": {
        "welcome": "👁️ *TITAN-94 «ОКО НЕБЕСНОЕ»* активирован\n\n🔰 Автономный AI-организм безопасности TON\n\n💎 Кошелёк: `UQC8seFr9xyA47kG2OIDRnKST8_1qPw3EN5pk6XlKLuNl-8v`\n\n⚡ 72ч PRO Trial активирован!",
        "choose_lang": "🌐 Выберите язык:",
        "open_terminal": "◈ TITAN Terminal",
        "stats_title": "📊 *Статистика TITAN-94*",
        "scan_ok": "👁️ Сканирование запущено! Результаты в /threats",
        "no_address": "❌ Укажите адрес: /analyze EQ...",
        "analyzing": "🧠 Анализирую контракт... (Gemini AI)",
        "honeypot_analyzing": "🍯 Проверяю на HoneyPot...",
        "threats_title": "🚨 *Активные угрозы:*",
        "wallet_title": "💎 *Reserve Fund*",
        "earn_title": "💰 *EARN CENTER*\n\n🎯 Trial 72ч PRO\n⚔️ Рефералы 10+10\n🏆 Bounty Hunter",
        "arb_title": "📈 *DEX Арбитраж*",
        "heal_title": "⚡ *Цикл лечения запущен*",
    }
}

def t(uid: int, key: str) -> str:
    lang = user_lang.get(uid, "ua")
    return TEXTS.get(lang, TEXTS["ua"]).get(key, key)

def lang(uid: int) -> str:
    return user_lang.get(uid, "ua")

# ── API helper ────────────────────────────────────────────────
async def api(path: str, method="GET", json_data=None):
    async with aiohttp.ClientSession() as s:
        fn = s.post if method == "POST" else s.get
        async with fn(f"{API_URL}{path}", json=json_data, timeout=aiohttp.ClientTimeout(total=15)) as r:
            return await r.json()

# ── Keyboards ─────────────────────────────────────────────────
def main_kb(uid: int) -> InlineKeyboardMarkup:
    b = InlineKeyboardBuilder()
    b.button(text="◈ TITAN Terminal", web_app=WebAppInfo(url=MINI_APP_URL))
    b.button(text="📊 Stats", callback_data="stats")
    b.button(text="🚨 Threats", callback_data="threats")
    b.button(text="💎 Wallet", callback_data="wallet")
    b.button(text="📈 Arb", callback_data="arb")
    b.button(text="💰 Earn", callback_data="earn")
    b.button(text="🌐 Lang", callback_data="lang")
    b.adjust(1, 3, 3)
    return b.as_markup()

def lang_kb() -> InlineKeyboardMarkup:
    b = InlineKeyboardBuilder()
    b.button(text="🇺🇦 Українська", callback_data="setlang_ua")
    b.button(text="🇬🇧 English", callback_data="setlang_en")
    b.button(text="🇷🇺 Русский", callback_data="setlang_ru")
    b.adjust(1)
    return b.as_markup()

# ── /start ────────────────────────────────────────────────────
@dp.message(CommandStart())
async def cmd_start(msg: types.Message):
    uid = msg.from_user.id
    # Auto-trial
    try:
        await api("/earn/trial/start", "POST", {"telegramId": uid, "username": msg.from_user.username})
    except: pass

    await msg.answer(t(uid, "welcome"), parse_mode="Markdown", reply_markup=main_kb(uid))

# ── /lang ─────────────────────────────────────────────────────
@dp.message(Command("lang"))
async def cmd_lang(msg: types.Message):
    await msg.answer(t(msg.from_user.id, "choose_lang"), reply_markup=lang_kb())

@dp.callback_query(F.data.startswith("setlang_"))
async def cb_lang(cb: types.CallbackQuery):
    lang_code = cb.data.split("_")[1]
    user_lang[cb.from_user.id] = lang_code
    await cb.message.edit_text(f"✅ Language set: {lang_code.upper()}")
    await cb.answer()

@dp.callback_query(F.data == "lang")
async def cb_lang_menu(cb: types.CallbackQuery):
    await cb.message.answer(t(cb.from_user.id, "choose_lang"), reply_markup=lang_kb())
    await cb.answer()

# ── /stats ────────────────────────────────────────────────────
@dp.message(Command("stats"))
@dp.callback_query(F.data == "stats")
async def cmd_stats(event):
    msg = event if isinstance(event, types.Message) else event.message
    uid = (event if isinstance(event, types.Message) else event.from_user).id if isinstance(event, types.Message) else event.from_user.id
    try:
        s = await api("/agent/stats")
        c = await api("/agent/cycles")
        text = f"{t(uid, 'stats_title')}\n\n"
        text += f"🔍 Threats: `{s.get('threatsDetected', 0)}`\n"
        text += f"⚡ Healed: `{s.get('threatsHealed', 0)}`\n"
        text += f"🧠 AI Accuracy: `{round(s.get('aiAccuracy', 0) * 100, 1)}%`\n"
        text += f"📚 Patterns: `{s.get('knowledgePatterns', 0)}`\n"
        text += f"👥 Subscribers: `{s.get('activeSubscribers', 0)}`\n"
        text += f"⚙️ Cycles: `{s.get('cycleCount', 0)}`\n\n"
        for cyc in c.get("cycles", []):
            icon = {"SCAN":"👁️","HEAL":"⚡","LEARN":"🧠","FINANCE":"💰"}.get(cyc["name"],"•")
            text += f"{icon} `{cyc['name']}` #{cyc['runCount']} — {cyc['status']}\n"
        await msg.answer(text, parse_mode="Markdown")
    except Exception as e:
        await msg.answer(f"❌ Error: {e}")
    if isinstance(event, types.CallbackQuery):
        await event.answer()

# ── /scan ─────────────────────────────────────────────────────
@dp.message(Command("scan"))
async def cmd_scan(msg: types.Message):
    await api("/agent/scan", "POST")
    await msg.answer(t(msg.from_user.id, "scan_ok"), parse_mode="Markdown")

# ── /analyze ──────────────────────────────────────────────────
@dp.message(Command("analyze"))
async def cmd_analyze(msg: types.Message):
    uid = msg.from_user.id
    parts = msg.text.split(maxsplit=1)
    if len(parts) < 2:
        return await msg.answer(t(uid, "no_address"))
    addr = parts[1].strip()
    wait = await msg.answer(t(uid, "analyzing"))
    try:
        r = await api("/analyze", "POST", {"address": addr})
        score = r.get("riskScore", 0)
        level = r.get("riskLevel", "UNKNOWN")
        emoji = "🟢" if score < 30 else "🟡" if score < 70 else "🔴"
        text = f"{emoji} *Analysis: {addr[:20]}...*\n\n"
        text += f"Risk: `{score}/100` — {level}\n\n"
        text += f"📝 {r.get('summary', '')}\n\n"
        vulns = r.get("vulnerabilities", [])
        if vulns:
            text += "⚠️ *Vulnerabilities:*\n" + "\n".join(f"• {v}" for v in vulns[:5]) + "\n\n"
        earn = r.get("earningOpportunity", "")
        if earn:
            text += f"💡 *Opportunity:* {earn}"
        await wait.edit_text(text, parse_mode="Markdown")
    except Exception as e:
        await wait.edit_text(f"❌ {e}")

# ── /honeypot ─────────────────────────────────────────────────
@dp.message(Command("honeypot"))
async def cmd_honeypot(msg: types.Message):
    uid = msg.from_user.id
    parts = msg.text.split(maxsplit=1)
    if len(parts) < 2:
        return await msg.answer("❌ /honeypot EQ...")
    addr = parts[1].strip()
    wait = await msg.answer(t(uid, "honeypot_analyzing"))
    try:
        r = await api("/analyze/honeypot", "POST", {"address": addr})
        emoji = "🔴 HONEYPOT!" if r.get("isHoneypot") else "🟢 SAFE"
        text = f"{emoji}\n\n"
        text += f"Confidence: `{r.get('confidence', 0)}%`\n"
        text += f"Buy: {'✅' if r.get('canBuy') else '❌'} | Sell: {'✅' if r.get('canSell') else '❌'}\n"
        text += f"Tax B/S: `{r.get('buyTax',0)}%` / `{r.get('sellTax',0)}%`\n\n"
        signals = r.get("signals", [])
        if signals:
            text += "Signals:\n" + "\n".join(f"• {s}" for s in signals[:5])
        await wait.edit_text(text, parse_mode="Markdown")
    except Exception as e:
        await wait.edit_text(f"❌ {e}")

# ── /threats ─────────────────────────────────────────────────
@dp.message(Command("threats"))
@dp.callback_query(F.data == "threats")
async def cmd_threats(event):
    msg = event if isinstance(event, types.Message) else event.message
    uid = msg.from_user.id
    try:
        r = await api("/vulnerabilities")
        vulns = r.get("vulnerabilities", [])[:5]
        text = t(uid, "threats_title") + "\n\n"
        for v in vulns:
            sev = v.get("severity","?")
            icon = {"critical":"🔴","high":"🟠","medium":"🟡","low":"🟢"}.get(sev,"⚫")
            text += f"{icon} *{v.get('title','?')}*\n"
            text += f"   Protocol: `{v.get('protocol','?')}` | TVL: `${v.get('tvlAtRisk','?')}`\n\n"
        if not vulns:
            text += "✅ No active threats"
        await msg.answer(text, parse_mode="Markdown")
    except Exception as e:
        await msg.answer(f"❌ {e}")
    if isinstance(event, types.CallbackQuery):
        await event.answer()

# ── /wallet ───────────────────────────────────────────────────
@dp.message(Command("wallet"))
@dp.callback_query(F.data == "wallet")
async def cmd_wallet(event):
    msg = event if isinstance(event, types.Message) else event.message
    uid = msg.from_user.id
    try:
        w = await api("/ton/wallet")
        text = f"{t(uid, 'wallet_title')}\n\n"
        text += f"Balance: `{w.get('balance_ton', '?')} TON`\n"
        text += f"Status: `{w.get('status', '?')}`\n"
        text += f"Address:\n`{w.get('address','?')}`\n\n"
        text += "📊 [View on TONViewer](https://tonviewer.com/UQC8seFr9xyA47kG2OIDRnKST8_1qPw3EN5pk6XlKLuNl-8v)"
        await msg.answer(text, parse_mode="Markdown")
    except Exception as e:
        await msg.answer(f"❌ {e}")
    if isinstance(event, types.CallbackQuery):
        await event.answer()

# ── /arb ──────────────────────────────────────────────────────
@dp.message(Command("arb"))
@dp.callback_query(F.data == "arb")
async def cmd_arb(event):
    msg = event if isinstance(event, types.Message) else event.message
    uid = msg.from_user.id
    try:
        r = await api("/arbitrage/opportunities")
        opps = r.get("opportunities", [])
        text = t(uid, "arb_title") + "\n\n"
        for o in opps:
            status_icon = "🟢" if o.get("status") == "ACTIVE" else "🟡"
            text += f"{status_icon} *{o.get('pair')}* spread: `{o.get('spread')}%`\n"
            text += f"   STON: `{o.get('stonfi')}` | DeDust: `{o.get('dedust')}`\n"
            text += f"   Profit: `+{o.get('profit')} TON`\n\n"
        await msg.answer(text, parse_mode="Markdown")
    except Exception as e:
        await msg.answer(f"❌ {e}")
    if isinstance(event, types.CallbackQuery):
        await event.answer()

# ── /earn ─────────────────────────────────────────────────────
@dp.message(Command("earn"))
@dp.callback_query(F.data == "earn")
async def cmd_earn(event):
    msg = event if isinstance(event, types.Message) else event.message
    uid = msg.from_user.id
    try:
        trial = await api(f"/earn/trial/status?telegramId={uid}")
        bounty = await api("/earn/bounty")
        text = t(uid, "earn_title") + "\n\n"
        text += f"🎯 *Trial:* `{trial.get('planName','?')}` expires `{str(trial.get('expiresAt','?'))[:10]}`\n"
        text += f"🔑 Ref code: `{trial.get('referralCode','?')}`\n\n"
        text += f"🏆 *Bounties:* ${bounty.get('totalAvailable',0)} total\n"
        for b in bounty.get("bounties", [])[:3]:
            text += f"• {b['protocol']}: `${b['reward']}` — {b['description'][:40]}...\n"
        await msg.answer(text, parse_mode="Markdown")
    except Exception as e:
        await msg.answer(f"❌ {e}")
    if isinstance(event, types.CallbackQuery):
        await event.answer()

# ── /heal ─────────────────────────────────────────────────────
@dp.message(Command("heal"))
async def cmd_heal(msg: types.Message):
    await api("/ai-evolution/trigger", "POST")
    await msg.answer(t(msg.from_user.id, "heal_title"), parse_mode="Markdown")

# ── Free-text: AI assistant ────────────────────────────────────
@dp.message()
async def ai_chat(msg: types.Message):
    if not msg.text or msg.text.startswith("/"):
        return
    wait = await msg.answer("🧠 Thinking...")
    try:
        r = await api("/analyze", "POST", {"text": msg.text})
        summary = r.get("summary", str(r))[:800]
        await wait.edit_text(f"👁️ TITAN-94:\n\n{summary}")
    except Exception as e:
        await wait.edit_text(f"❌ {e}")

# ── Main ──────────────────────────────────────────────────────
async def main():
    print("╔══════════════════════════════╗")
    print("║ TITAN-94 BOT ONLINE          ║")
    print("╚══════════════════════════════╝")
    await dp.start_polling(bot)

if __name__ == "__main__":
    asyncio.run(main())
