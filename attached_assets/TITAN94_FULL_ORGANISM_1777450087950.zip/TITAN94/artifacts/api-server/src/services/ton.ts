const TON_API = "https://toncenter.com/api/v2";
const RESERVE_WALLET = "UQC8seFr9xyA47kG2OIDRnKST8_1qPw3EN5pk6XlKLuNl-8v";
const API_KEY = process.env.TON_API_KEY || "";

const headers = API_KEY ? { "X-API-Key": API_KEY } : {};

async function tonFetch(path: string) {
  const res = await fetch(`${TON_API}${path}`, { headers });
  if (!res.ok) throw new Error(`TON API ${res.status}: ${path}`);
  const data = await res.json();
  if (!data.ok) throw new Error(data.error || "TON API error");
  return data.result;
}

export async function getTONNetwork() {
  return tonFetch("/getMasterchainInfo");
}

export async function getWalletBalance() {
  const info = await tonFetch(`/getAddressInformation?address=${RESERVE_WALLET}`);
  return {
    address: RESERVE_WALLET,
    balance_ton: (Number(info.balance) / 1e9).toFixed(4),
    status: info.state,
  };
}

export async function getTransactions(limit = 20) {
  const txs = await tonFetch(
    `/getTransactions?address=${RESERVE_WALLET}&limit=${limit}`
  );
  return txs.map((tx: any) => ({
    hash: tx.transaction_id?.hash,
    amount_ton: (Math.abs(tx.in_msg?.value ?? tx.out_msgs?.[0]?.value ?? 0) / 1e9).toFixed(4),
    direction: tx.in_msg?.source === RESERVE_WALLET ? "out" : "in",
    timestamp: new Date(tx.utime * 1000).toISOString(),
    from: tx.in_msg?.source,
    to: tx.out_msgs?.[0]?.destination,
  }));
}

export async function getContractInfo(address: string) {
  return tonFetch(`/getAddressInformation?address=${address}`);
}

export { RESERVE_WALLET };
