import { GoogleGenerativeAI } from "@google/generative-ai";

const genAI = new GoogleGenerativeAI(process.env.GEMINI_API_KEY || "");

export async function geminiAnalyze(prompt: string): Promise<string> {
  if (!process.env.GEMINI_API_KEY) {
    return "[MOCK] GEMINI_API_KEY not set. Add it to Secrets to enable real AI analysis.";
  }
  try {
    // Try Pro first, fallback to Flash
    let model = genAI.getGenerativeModel({ model: "gemini-2.5-pro" });
    try {
      const result = await model.generateContent(prompt);
      return result.response.text();
    } catch {
      model = genAI.getGenerativeModel({ model: "gemini-2.0-flash" });
      const result = await model.generateContent(prompt);
      return result.response.text();
    }
  } catch (e: any) {
    throw new Error(`Gemini error: ${e.message}`);
  }
}
