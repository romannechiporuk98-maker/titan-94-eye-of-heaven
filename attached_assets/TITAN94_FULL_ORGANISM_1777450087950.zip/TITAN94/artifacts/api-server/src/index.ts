import "dotenv/config";
import { createApp } from "./app.js";
import { startHeartbeat } from "./services/heartbeat.js";
import { db } from "./services/db.js";

const PORT = parseInt(process.env.PORT || "8080");

const app = createApp();

app.listen(PORT, () => {
  console.log(`\n╔══════════════════════════════════════╗`);
  console.log(`║   TITAN-94 «ОКО НЕБЕСНЕ» ONLINE     ║`);
  console.log(`║   API Server → http://localhost:${PORT}  ║`);
  console.log(`║   Version: 3.2.0-OMNIPOTENT          ║`);
  console.log(`╚══════════════════════════════════════╝\n`);
  startHeartbeat();
});

// Self-healing: uncaught exceptions
process.on("uncaughtException", (err) => {
  console.error("[SENTINEL] Uncaught exception:", err.message);
});
process.on("unhandledRejection", (reason) => {
  console.error("[SENTINEL] Unhandled rejection:", reason);
});
