import { Request, Response, NextFunction } from "express";
import crypto from "crypto";

const BOT_TOKEN = process.env.TELEGRAM_BOT_TOKEN || "";
const ADMIN_TG_ID = process.env.ADMIN_TELEGRAM_ID || "7255058720";

export interface TelegramUser {
  id: number;
  username?: string;
  first_name?: string;
  is_admin: boolean;
  plan: "free" | "pro" | "elite";
}

declare global {
  namespace Express {
    interface Request {
      telegramUser?: TelegramUser;
    }
  }
}

export function telegramAuthMiddleware(req: Request, _res: Response, next: NextFunction) {
  const initData = req.headers["x-telegram-init-data"] as string;
  if (!initData || !BOT_TOKEN) {
    return next(); // public access
  }

  try {
    const params = new URLSearchParams(initData);
    const hash = params.get("hash");
    if (!hash) return next();

    params.delete("hash");
    const dataCheckString = Array.from(params.entries())
      .sort(([a], [b]) => a.localeCompare(b))
      .map(([k, v]) => `${k}=${v}`)
      .join("\n");

    const secretKey = crypto.createHmac("sha256", "WebAppData").update(BOT_TOKEN).digest();
    const expectedHash = crypto.createHmac("sha256", secretKey).update(dataCheckString).digest("hex");

    if (expectedHash === hash) {
      const userStr = params.get("user");
      if (userStr) {
        const u = JSON.parse(userStr);
        req.telegramUser = {
          id: u.id,
          username: u.username,
          first_name: u.first_name,
          is_admin: String(u.id) === ADMIN_TG_ID,
          plan: String(u.id) === ADMIN_TG_ID ? "elite" : "free",
        };
      }
    }
  } catch {}
  next();
}

export function requireAdmin(req: Request, res: Response, next: NextFunction) {
  if (!req.telegramUser?.is_admin) {
    return res.status(403).json({ error: "Admin only" });
  }
  next();
}
