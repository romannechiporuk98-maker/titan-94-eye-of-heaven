import express from "express";
import cors from "cors";
import rateLimit from "express-rate-limit";
import { telegramAuthMiddleware } from "./middlewares/telegram-auth.js";

// Routes
import healthRouter from "./routes/health.js";
import authRouter from "./routes/auth.js";
import agentRouter from "./routes/agent.js";
import vulnerabilitiesRouter from "./routes/vulnerabilities.js";
import activityRouter from "./routes/activity.js";
import competitorsRouter from "./routes/competitors.js";
import tonRouter from "./routes/ton.js";
import analyzeRouter from "./routes/analyze.js";
import arbitrageRouter from "./routes/arbitrage.js";
import monetizationRouter from "./routes/monetization.js";
import aiEvolutionRouter from "./routes/ai-evolution.js";
import ecosystemRouter from "./routes/ecosystem.js";
import earnRouter from "./routes/earn.js";
import webhookRouter from "./routes/webhook.js";

export function createApp() {
  const app = express();

  // ── CORS ────────────────────────────────────────────────────
  app.use(cors({ origin: "*", methods: ["GET", "POST", "PUT", "DELETE"] }));

  // ── Body parser ─────────────────────────────────────────────
  app.use(express.json({ limit: "2mb" }));

  // ── Rate Limit ──────────────────────────────────────────────
  app.use(
    "/api",
    rateLimit({
      windowMs: 60 * 60 * 1000, // 1 hour
      max: 120,
      message: { error: "Rate limit exceeded. SENTINEL active." },
      standardHeaders: true,
    })
  );

  // ── Telegram HMAC Auth Middleware ────────────────────────────
  app.use("/api", telegramAuthMiddleware);

  // ── SENTINEL: Anomaly detection ─────────────────────────────
  app.use("/api", (req, _res, next) => {
    const suspicious = /(select|union|drop|insert|<script|\.\.\/)/i;
    const input = JSON.stringify(req.body) + req.url;
    if (suspicious.test(input)) {
      console.warn(`[SENTINEL] Suspicious request blocked: ${req.ip} → ${req.url}`);
      return _res.status(400).json({ error: "Request blocked by SENTINEL" });
    }
    next();
  });

  // ── Routes ───────────────────────────────────────────────────
  app.use("/api", healthRouter);
  app.use("/api/auth", authRouter);
  app.use("/api/agent", agentRouter);
  app.use("/api/vulnerabilities", vulnerabilitiesRouter);
  app.use("/api/activity", activityRouter);
  app.use("/api/competitors", competitorsRouter);
  app.use("/api/ton", tonRouter);
  app.use("/api/analyze", analyzeRouter);
  app.use("/api/arbitrage", arbitrageRouter);
  app.use("/api/monetization", monetizationRouter);
  app.use("/api/ai-evolution", aiEvolutionRouter);
  app.use("/api/ecosystem", ecosystemRouter);
  app.use("/api/earn", earnRouter);
  app.use("/api/webhook", webhookRouter);

  // ── Global error handler ─────────────────────────────────────
  app.use((err: Error, _req: express.Request, res: express.Response, _next: express.NextFunction) => {
    console.error("[TITAN-94 ERROR]", err.message);
    res.status(500).json({ error: "Internal server error", message: err.message });
  });

  return app;
}
