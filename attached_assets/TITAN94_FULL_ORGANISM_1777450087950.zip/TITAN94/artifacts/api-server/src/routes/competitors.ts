export { competitorsRouter as default } from "./_all.js";
