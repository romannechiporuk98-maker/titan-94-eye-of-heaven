export { ecosystemRouter as default } from "./_all.js";
