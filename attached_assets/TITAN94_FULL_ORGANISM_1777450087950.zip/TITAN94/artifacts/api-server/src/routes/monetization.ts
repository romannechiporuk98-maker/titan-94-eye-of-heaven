import { Router } from "express";
import { db, schema } from "../services/db.js";
import { eq, sql } from "drizzle-orm";
import { randomUUID } from "crypto";

const router = Router();

const PLANS = [
  { id: "free", name: "FREE", price: 0, priceTon: 0, features: ["5 scans/day", "Basic alerts", "TON monitor"], duration: null },
  { id: "pro", name: "PRO", price: 5, priceTon: 5, features: ["Unlimited scans", "Gemini AI analysis", "HoneyPot detector", "Real-time alerts"], duration: 30 },
  { id: "elite", name: "ELITE", price: 20, priceTon: 20, features: ["Everything in PRO", "Arbitrage signals", "API access", "Whale alerts", "Private AI"], duration: 30 },
];

router.get("/plans", (_req, res) => res.json({ plans: PLANS }));

router.post("/subscribe", async (req, res) => {
  const { planId, walletAddress, telegramId, username } = req.body;
  const plan = PLANS.find(p => p.id === planId);
  if (!plan) return res.status(400).json({ error: "Invalid plan" });

  const expiresAt = plan.duration ? new Date(Date.now() + plan.duration * 86400000) : new Date("2099-01-01");

  try {
    await db.insert(schema.subscriptions).values({
      id: randomUUID(),
      externalId: `sub-${telegramId || randomUUID()}`,
      planId: plan.id,
      planName: plan.name,
      telegramId: String(telegramId || ""),
      username: username || "",
      walletAddress: walletAddress || "",
      amountPaidTon: plan.priceTon,
      status: plan.id === "free" ? "active" : "pending",
      expiresAt,
      createdAt: new Date(),
      updatedAt: new Date(),
    }).onConflictDoUpdate({
      target: schema.subscriptions.externalId,
      set: { planId: plan.id, planName: plan.name, status: plan.id === "free" ? "active" : "pending", updatedAt: new Date() },
    });

    res.json({ success: true, plan: plan.name, status: plan.id === "free" ? "active" : "pending", expiresAt, reserveWallet: "UQC8seFr9xyA47kG2OIDRnKST8_1qPw3EN5pk6XlKLuNl-8v" });
  } catch (e: any) {
    res.status(500).json({ error: e.message });
  }
});

router.get("/revenue", async (_req, res) => {
  try {
    const [total, active] = await Promise.all([
      db.select({ sum: sql<number>`SUM(amount_paid_ton)` }).from(schema.subscriptions),
      db.select({ count: sql<number>`COUNT(*)` }).from(schema.subscriptions).where(eq(schema.subscriptions.status, "active")),
    ]);
    res.json({
      totalRevenueTon: Number(total[0]?.sum ?? 0).toFixed(2),
      activeSubscribers: Number(active[0]?.count ?? 0),
      monthlyRevenueTon: (Number(active[0]?.count ?? 0) * 7.5).toFixed(2),
    });
  } catch (e: any) {
    res.status(500).json({ error: e.message });
  }
});

router.get("/subscribers", async (_req, res) => {
  try {
    const subs = await db.select().from(schema.subscriptions).orderBy(schema.subscriptions.createdAt);
    res.json({ subscribers: subs });
  } catch (e: any) {
    res.status(500).json({ error: e.message });
  }
});

router.get("/status", async (req, res) => {
  const telegramId = req.query.telegramId as string;
  if (!telegramId) return res.json({ plan: "free", status: "active" });
  try {
    const sub = await db.select().from(schema.subscriptions)
      .where(eq(schema.subscriptions.telegramId, telegramId))
      .limit(1);
    res.json(sub[0] ?? { plan: "free", status: "active", telegramId });
  } catch (e: any) {
    res.status(500).json({ error: e.message });
  }
});

export default router;
