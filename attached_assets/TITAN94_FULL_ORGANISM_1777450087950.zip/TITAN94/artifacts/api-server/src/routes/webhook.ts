import { Router } from "express";
import { db, schema } from "../services/db.js";
import { eq, sql } from "drizzle-orm";
import { randomUUID } from "crypto";

// ── WEBHOOK: TON payments ──────────────────────────────────────
const webhookRouter = Router();

webhookRouter.post("/ton-payment", async (req, res) => {
  const { txHash, fromAddress, amountNano } = req.body;
  const amountTon = Number(amountNano) / 1e9;

  let plan = "unknown";
  if (amountTon >= 4.5 && amountTon <= 5.5) plan = "pro";
  else if (amountTon >= 19 && amountTon <= 21) plan = "elite";
  else return res.json({ received: true, plan: "unknown", note: "Amount not matched" });

  const expiresAt = new Date(Date.now() + 30 * 86400000);

  await db.insert(schema.subscriptions).values({
    id: randomUUID(),
    externalId: `sub-${fromAddress}`,
    planId: plan,
    planName: plan.toUpperCase(),
    telegramId: "",
    username: "",
    walletAddress: fromAddress,
    amountPaidTon: amountTon,
    status: "active",
    expiresAt,
    createdAt: new Date(),
    updatedAt: new Date(),
  }).onConflictDoUpdate({
    target: schema.subscriptions.externalId,
    set: { planId: plan, planName: plan.toUpperCase(), status: "active", expiresAt, amountPaidTon: amountTon, updatedAt: new Date() },
  }).catch(() => {});

  await db.insert(schema.activity).values({
    id: randomUUID(),
    type: "payment",
    title: `${plan.toUpperCase()} subscription activated`,
    message: `💰 Payment received: ${amountTon} TON from ${fromAddress}. TX: ${txHash}`,
    severity: "info",
    metadata: { txHash, fromAddress, amountTon, plan },
    createdAt: new Date(),
  }).catch(() => {});

  res.json({ success: true, plan, expiresAt, txHash });
});

webhookRouter.get("/verify/:txHash", (_req, res) => {
  res.json({ verified: true, txHash: _req.params.txHash, note: "Production: verify via TonCenter API" });
});

// ── EARN: Trial + Referral + Bounty ───────────────────────────
export const earnRouter = Router();

earnRouter.post("/trial/start", async (req, res) => {
  const { telegramId, username } = req.body;
  if (!telegramId) return res.status(400).json({ error: "telegramId required" });

  const trialExpiresAt = new Date(Date.now() + 72 * 3600000);
  const referralCode = `TITAN${Math.random().toString(36).substring(2, 8).toUpperCase()}`;
  const externalId = `sub-trial-${telegramId}`;

  try {
    await db.insert(schema.subscriptions).values({
      id: randomUUID(),
      externalId,
      planId: "pro",
      planName: "PRO TRIAL",
      telegramId: String(telegramId),
      username: username || "",
      walletAddress: "",
      amountPaidTon: 0,
      status: "active",
      expiresAt: trialExpiresAt,
      referralCode,
      trialAuditsUsed: 0,
      createdAt: new Date(),
      updatedAt: new Date(),
    }).onConflictDoNothing();

    res.json({ success: true, trialExpiresAt, auditsLeft: 3, referralCode });
  } catch (e: any) {
    res.status(500).json({ error: e.message });
  }
});

earnRouter.get("/trial/status", async (req, res) => {
  const { telegramId } = req.query;
  if (!telegramId) return res.status(400).json({ error: "telegramId required" });
  const sub = await db.select().from(schema.subscriptions)
    .where(eq(schema.subscriptions.telegramId, String(telegramId))).limit(1);
  res.json(sub[0] ?? { plan: "free", status: "none" });
});

earnRouter.post("/referral/register", async (req, res) => {
  const { telegramId, referralCode } = req.body;
  res.json({ success: true, message: "Referral registered", telegramId, referralCode, bonus: "+2 days trial" });
});

earnRouter.get("/bounty", (_req, res) => {
  res.json({
    bounties: [
      { protocol: "DeDust", reward: 2000, currency: "USD", description: "Critical reentrancy in swap", status: "open" },
      { protocol: "STON.fi", reward: 1500, currency: "USD", description: "LP overflow", status: "open" },
      { protocol: "Megaton", reward: 800, currency: "USD", description: "Oracle price manipulation", status: "open" },
      { protocol: "TON Bridge", reward: 1200, currency: "USD", description: "Signature replay", status: "open" },
      { protocol: "Evaa", reward: 600, currency: "USD", description: "Flash loan attack vector", status: "open" },
    ],
    titanShare: "10%",
    reporterShare: "90%",
    totalAvailable: 6100,
  });
});

export default webhookRouter;
