// ── health.ts ─────────────────────────────────────────────────
import { Router } from "express";
export default Router().get("/healthz", (_req, res) => {
  res.json({ status: "ok", system: "TITAN-94", version: "3.2.0", timestamp: new Date().toISOString() });
});
