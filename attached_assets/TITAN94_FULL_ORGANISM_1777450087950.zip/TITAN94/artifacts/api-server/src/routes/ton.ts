import { Router } from "express";
import { getTONNetwork, getWalletBalance, getTransactions, getContractInfo } from "../services/ton.js";

const router = Router();

router.get("/network", async (_req, res) => {
  try { res.json(await getTONNetwork()); }
  catch (e: any) { res.status(500).json({ error: e.message }); }
});

router.get("/wallet", async (_req, res) => {
  try { res.json(await getWalletBalance()); }
  catch (e: any) { res.status(500).json({ error: e.message }); }
});

router.get("/transactions", async (req, res) => {
  const limit = Number(req.query.limit) || 20;
  try { res.json(await getTransactions(limit)); }
  catch (e: any) { res.status(500).json({ error: e.message }); }
});

router.get("/contract/:address", async (req, res) => {
  try { res.json(await getContractInfo(req.params.address)); }
  catch (e: any) { res.status(500).json({ error: e.message }); }
});

export default router;
