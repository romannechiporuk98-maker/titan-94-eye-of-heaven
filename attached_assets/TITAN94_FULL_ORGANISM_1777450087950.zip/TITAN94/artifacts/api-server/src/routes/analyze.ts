import { Router } from "express";
import { geminiAnalyze } from "../services/gemini.js";
import { getContractInfo } from "../services/ton.js";

const router = Router();

// POST /api/analyze — Gemini AI contract analysis
router.post("/", async (req, res) => {
  const { address, text } = req.body;
  if (!address && !text) return res.status(400).json({ error: "address or text required" });

  try {
    let contractInfo = "";
    if (address) {
      const info = await getContractInfo(address).catch(() => null);
      contractInfo = info ? `\nContract state: ${JSON.stringify(info)}` : "";
    }

    const prompt = `You are TITAN-94, an expert TON blockchain security AI.
Analyze this TON smart contract address/code and provide a detailed security report.
Target: ${address || text}${contractInfo}

Respond with JSON only:
{
  "riskScore": 0-100,
  "riskLevel": "SAFE|WARNING|DANGER|CRITICAL",
  "isHoneypot": true/false,
  "vulnerabilities": ["list of found vulnerabilities"],
  "recommendations": ["list of fixes"],
  "summary": "brief explanation",
  "earningOpportunity": "if safe, describe how to earn from this"
}`;

    const raw = await geminiAnalyze(prompt);
    let result;
    try {
      const clean = raw.replace(/```json|```/g, "").trim();
      result = JSON.parse(clean);
    } catch {
      result = { summary: raw, riskScore: 0, riskLevel: "UNKNOWN", vulnerabilities: [], recommendations: [] };
    }

    res.json(result);
  } catch (e: any) {
    res.status(500).json({ error: e.message });
  }
});

// POST /api/analyze/honeypot
router.post("/honeypot", async (req, res) => {
  const { address } = req.body;
  if (!address) return res.status(400).json({ error: "address required" });

  try {
    const info = await getContractInfo(address).catch(() => ({ state: "unknown" }));

    const prompt = `You are TITAN-94 HoneyPot Detector for TON blockchain.
Analyze this address for honeypot characteristics: ${address}
State: ${JSON.stringify(info)}

Return JSON only:
{
  "isHoneypot": true/false,
  "confidence": 0-100,
  "signals": ["list of detected signals"],
  "canBuy": true/false,
  "canSell": true/false,
  "buyTax": 0-100,
  "sellTax": 0-100,
  "verdict": "SAFE|SUSPICIOUS|HONEYPOT",
  "explanation": "brief"
}`;

    const raw = await geminiAnalyze(prompt);
    let result;
    try {
      const clean = raw.replace(/```json|```/g, "").trim();
      result = JSON.parse(clean);
    } catch {
      result = {
        isHoneypot: false, confidence: 50, signals: [],
        canBuy: true, canSell: true, buyTax: 0, sellTax: 0,
        verdict: "UNKNOWN", explanation: raw
      };
    }

    res.json(result);
  } catch (e: any) {
    res.status(500).json({ error: e.message });
  }
});

export default router;
