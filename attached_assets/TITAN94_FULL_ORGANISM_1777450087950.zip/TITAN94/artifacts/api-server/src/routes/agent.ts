import { Router } from "express";
import { db, schema } from "../services/db.js";
import { eq, sql, desc } from "drizzle-orm";
import { getCycleStatus } from "../services/heartbeat.js";
import { randomUUID } from "crypto";

const router = Router();

// GET /api/agent/stats
router.get("/stats", async (_req, res) => {
  try {
    const [vulns, knowledge, subs] = await Promise.all([
      db.select({ count: sql<number>`COUNT(*)` }).from(schema.vulnerabilities),
      db.select({ count: sql<number>`COUNT(*)`, avgConf: sql<number>`AVG(CAST(confidence AS FLOAT))` }).from(schema.knowledge),
      db.select({ count: sql<number>`COUNT(*)` }).from(schema.subscriptions).where(eq(schema.subscriptions.status, "active")),
    ]);

    const healCycles = getCycleStatus().find(c => c.name === "HEAL")?.runCount ?? 0;
    const learnCycles = getCycleStatus().find(c => c.name === "LEARN")?.runCount ?? 0;

    res.json({
      threatsDetected: Number(vulns[0]?.count ?? 0),
      threatsHealed: healCycles * 2,
      aiAccuracy: Number(knowledge[0]?.avgConf ?? 0.94),
      cycleCount: getCycleStatus().reduce((a, c) => a + c.runCount, 0),
      knowledgePatterns: Number(knowledge[0]?.count ?? 0),
      activeSubscribers: Number(subs[0]?.count ?? 0),
      systemStatus: "ONLINE",
      version: "3.2.0-OMNIPOTENT",
    });
  } catch (e: any) {
    res.status(500).json({ error: e.message });
  }
});

// GET /api/agent/cycles
router.get("/cycles", (_req, res) => {
  res.json({ cycles: getCycleStatus() });
});

// POST /api/agent/scan
router.post("/scan", async (_req, res) => {
  const id = randomUUID();
  await db.insert(schema.activity).values({
    id,
    type: "manual_scan",
    title: "Manual Scan Triggered",
    message: "👁️ Manual network scan initiated by operator",
    severity: "info",
    metadata: { manual: true },
    createdAt: new Date(),
  }).catch(() => {});
  res.json({ success: true, message: "Scan initiated", scanId: id });
});

export default router;
