// vulnerabilities.ts
import { Router } from "express";
import { db, schema } from "../services/db.js";
import { eq } from "drizzle-orm";
export default Router().get("/", async (req, res) => {
  try {
    const { severity, status } = req.query;
    let q = db.select().from(schema.vulnerabilities);
    const vulns = await q;
    res.json({ vulnerabilities: vulns.filter(v =>
      (!severity || v.severity === severity) && (!status || v.status === status)
    )});
  } catch (e: any) { res.status(500).json({ error: e.message }); }
});
