export { activityRouter as default } from "./_all.js";
