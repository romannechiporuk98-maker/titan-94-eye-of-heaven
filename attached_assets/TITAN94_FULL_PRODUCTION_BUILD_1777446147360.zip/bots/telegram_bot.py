
import requests

API_URL = "http://localhost:8000/ingest"

def send_event(text):
    r = requests.post(API_URL, json={"text": text})
    return r.json()

if __name__ == "__main__":
    while True:
        msg = input("Enter message: ")
        print(send_event(msg))
