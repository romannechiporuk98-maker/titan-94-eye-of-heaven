
import React, { useState } from "react";

function App() {
  const [input, setInput] = useState("");
  const [result, setResult] = useState(null);

  const send = async () => {
    const res = await fetch("http://localhost:8000/ingest", {
      method: "POST",
      headers: {"Content-Type": "application/json"},
      body: JSON.stringify({text: input})
    });
    const data = await res.json();
    setResult(data);
  };

  return (
    <div>
      <h1>Titan94 Dashboard</h1>
      <input onChange={e => setInput(e.target.value)} />
      <button onClick={send}>Scan</button>
      <pre>{JSON.stringify(result, null, 2)}</pre>
    </div>
  );
}

export default App;
