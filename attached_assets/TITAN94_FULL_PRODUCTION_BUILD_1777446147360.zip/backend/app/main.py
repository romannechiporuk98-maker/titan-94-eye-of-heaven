
from fastapi import FastAPI
from app.routes import ingest

app = FastAPI(title="Titan94 Production")

app.include_router(ingest.router)

@app.get("/")
def root():
    return {"status": "Titan94 FULL PRODUCTION RUNNING"}
