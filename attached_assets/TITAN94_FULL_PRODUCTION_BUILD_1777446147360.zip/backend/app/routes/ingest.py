
from fastapi import APIRouter
from app.services.pipeline import run_pipeline

router = APIRouter()

@router.post("/ingest")
def ingest(data: dict):
    result = run_pipeline(data)
    return {"result": result}
