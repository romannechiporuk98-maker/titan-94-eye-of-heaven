
def detect_risk(data):
    text = str(data).lower()
    score = 0
    if "honeypot" in text:
        score += 70
    if "no liquidity" in text:
        score += 30
    return min(score, 100)
