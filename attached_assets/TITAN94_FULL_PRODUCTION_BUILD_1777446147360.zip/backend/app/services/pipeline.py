
from app.services.detector import detect_risk

def run_pipeline(data):
    score = detect_risk(data)
    if score > 80:
        return {"risk": score, "action": "AVOID"}
    elif score > 50:
        return {"risk": score, "action": "CAUTION"}
    return {"risk": score, "action": "OK"}
