
import subprocess, time, sys
while True:
    subprocess.call([sys.executable, "bot_main.py"])
    time.sleep(3)
