
import asyncio, websockets

async def handler(ws):
    while True:
        await ws.send("TITAN LIVE")
        await asyncio.sleep(2)

async def run():
    async with websockets.serve(handler, "0.0.0.0", 8765):
        await asyncio.Future()
