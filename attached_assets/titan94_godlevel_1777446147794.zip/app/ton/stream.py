
import asyncio, httpx

async def stream():
    while True:
        async with httpx.AsyncClient() as c:
            await c.get("https://toncenter.com/api/v2/getTransactions", params={"address":"EQ...", "limit":5})
        await asyncio.sleep(5)
