
def analyze(tx):
    risk = 0
    if "out_msgs" in tx and not tx["out_msgs"]:
        risk += 50
    if "fee" in tx and tx["fee"] > 1e9:
        risk += 20
    return risk
