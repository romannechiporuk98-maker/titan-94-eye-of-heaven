
from fastapi import FastAPI
import asyncio

app = FastAPI(title="TITAN-94 GODLEVEL")

@app.on_event("startup")
async def startup():
    asyncio.create_task(worker())

async def worker():
    while True:
        print("[WORKER] alive")
        await asyncio.sleep(2)

@app.get("/")
def root():
    return {"status": "TITAN-94 GOD CORE ONLINE"}
