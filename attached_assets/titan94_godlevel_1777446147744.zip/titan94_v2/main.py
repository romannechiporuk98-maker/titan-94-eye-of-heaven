"""
TITAN-94 GOD LEVEL — MAIN ENTRY POINT
Starts: FastAPI + WebSocket server + TON live stream + Telegram bot
"""
import asyncio
import threading
import uvicorn
from app.main import app
from app.ton.stream import TONStream
from app.ws.server import ws_broadcast_loop
from app.core.db import init_db

import os
from dotenv import load_dotenv
load_dotenv()


async def async_main():
    """Run all async services together"""
    await init_db()

    stream = TONStream()
    await asyncio.gather(
        stream.run(),
        ws_broadcast_loop(),
    )


def run_api():
    uvicorn.run(app, host="0.0.0.0", port=8080, log_level="warning")


def run_bot():
    from bot.bot_main import start_bot
    asyncio.run(start_bot())


if __name__ == "__main__":
    # Bot in background thread
    bot_thread = threading.Thread(target=run_bot, daemon=True)
    bot_thread.start()

    # Async services in background thread
    def run_async():
        asyncio.run(async_main())

    async_thread = threading.Thread(target=run_async, daemon=True)
    async_thread.start()

    # API in main thread (blocking)
    print("🛡  TITAN-94 GOD LEVEL — ONLINE")
    run_api()
