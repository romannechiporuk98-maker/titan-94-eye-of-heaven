"""TITAN-94 Bot Watcher — auto-restart on crash"""
import subprocess, sys, time, os

BOT = os.path.join(os.path.dirname(__file__), "bot_main.py")

restarts = 0
while True:
    print(f"🚀 Bot starting (run #{restarts+1})")
    p = subprocess.Popen([sys.executable, BOT])
    p.wait()
    restarts += 1
    if p.returncode == 0:
        print("Bot exited cleanly"); break
    print(f"⚠️  Crashed (exit {p.returncode}), restart in 5s...")
    time.sleep(5)
