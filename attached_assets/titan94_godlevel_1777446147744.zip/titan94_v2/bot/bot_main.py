"""
TITAN-94 Telegram Bot
Real commands, inline keyboards, live scan integration
"""
import asyncio
import os
import httpx
from aiogram import Bot, Dispatcher, types, F
from aiogram.filters import Command
from aiogram.types import InlineKeyboardMarkup, InlineKeyboardButton
from dotenv import load_dotenv

load_dotenv()

TOKEN = os.getenv("TELEGRAM_BOT_TOKEN", "")
OWNER = int(os.getenv("OWNER_ID", "0"))
API = os.getenv("API_BASE_URL", "http://localhost:8080")

bot = Bot(token=TOKEN) if TOKEN else None
dp = Dispatcher()

VERDICT_ICON = {"HONEYPOT": "🔴", "SUSPICIOUS": "🟠", "CAUTION": "🟡", "SAFE": "🟢"}


def kb_scan(addr: str) -> InlineKeyboardMarkup:
    return InlineKeyboardMarkup(inline_keyboard=[[
        InlineKeyboardButton(text="🔍 Deep Scan", callback_data=f"deep:{addr}"),
        InlineKeyboardButton(text="📋 History", callback_data="history"),
        InlineKeyboardButton(text="📊 Stats", callback_data="stats"),
    ]])


@dp.message(Command("start"))
async def start(m: types.Message):
    await m.answer(
        "🛡 *TITAN-94 GOD LEVEL*\nTON Autonomous Security System\n\n"
        "Commands:\n"
        "/scan `<address>` — scan address\n"
        "/watch `<address>` — add to watchlist\n"
        "/stats — statistics\n"
        "/alerts — recent alerts\n"
        "/stream — stream status\n\n"
        "_Or just send a TON address directly._",
        parse_mode="Markdown"
    )


@dp.message(Command("scan"))
async def cmd_scan(m: types.Message):
    parts = m.text.split(maxsplit=1)
    if len(parts) < 2:
        return await m.answer("Usage: `/scan EQ...`", parse_mode="Markdown")
    await _scan(m, parts[1].strip())


@dp.message(Command("stats"))
async def cmd_stats(m: types.Message):
    try:
        async with httpx.AsyncClient(timeout=5) as c:
            r = await c.get(f"{API}/api/stats")
            d = r.json()
        text = (
            "📊 *TITAN-94 Stats*\n\n"
            f"Scans: `{d.get('total_scans',0)}`\n"
            f"🔴 Honeypots: `{d.get('honeypots',0)}`\n"
            f"🟠 Suspicious: `{d.get('suspicious',0)}`\n"
            f"🟡 Caution: `{d.get('caution',0)}`\n"
            f"🟢 Safe: `{d.get('safe',0)}`\n"
            f"Alerts: `{d.get('total_alerts',0)}`"
        )
    except Exception as e:
        text = f"❌ {e}"
    await m.answer(text, parse_mode="Markdown")


@dp.message(Command("alerts"))
async def cmd_alerts(m: types.Message):
    try:
        async with httpx.AsyncClient(timeout=5) as c:
            r = await c.get(f"{API}/api/alerts?limit=5")
            alerts = r.json().get("alerts", [])
        if not alerts:
            return await m.answer("No alerts.")
        lines = ["🚨 *Recent Alerts*\n"]
        for a in alerts:
            icon = "🔴" if a["level"] == "CRITICAL" else "🟠" if a["level"] == "WARN" else "ℹ️"
            lines.append(f"{icon} `{a['level']}` {a['message']}")
        await m.answer("\n".join(lines), parse_mode="Markdown")
    except Exception as e:
        await m.answer(f"❌ {e}")


@dp.message(Command("stream"))
async def cmd_stream(m: types.Message):
    try:
        async with httpx.AsyncClient(timeout=5) as c:
            r = await c.get(f"{API}/api/stream/status")
            d = r.json()
        text = (
            "🌊 *Stream Status*\n\n"
            f"Running: `{d.get('running', False)}`\n"
            f"Ticks: `{d.get('ticks', 0)}`\n"
            f"Addresses seen: `{d.get('addresses_seen', 0)}`\n"
            f"Last tick: `{d.get('last_tick', 'N/A')}`"
        )
    except Exception as e:
        text = f"❌ {e}"
    await m.answer(text, parse_mode="Markdown")


@dp.callback_query(F.data.startswith("deep:"))
async def cb_deep(cb: types.CallbackQuery):
    await cb.answer("Running deep scan...")
    await _scan(cb.message, cb.data.split("deep:")[1], deep=True)


@dp.callback_query(F.data == "stats")
async def cb_stats(cb: types.CallbackQuery):
    await cb.answer()
    await cmd_stats(cb.message)


@dp.callback_query(F.data == "history")
async def cb_history(cb: types.CallbackQuery):
    await cb.answer()
    try:
        async with httpx.AsyncClient(timeout=5) as c:
            r = await c.get(f"{API}/api/history?limit=5")
            items = r.json().get("history", [])
        if not items:
            return await cb.message.answer("No history.")
        lines = ["📋 *Recent Scans*\n"]
        for h in items:
            icon = VERDICT_ICON.get(h.get("verdict", ""), "⚪")
            addr = h["address"][:14] + "..."
            lines.append(f"{icon} `{addr}` — {h['verdict']} ({h['risk_score']}%)")
        await cb.message.answer("\n".join(lines), parse_mode="Markdown")
    except Exception as e:
        await cb.message.answer(f"❌ {e}")


# Auto-scan raw TON addresses
@dp.message(F.text.regexp(r"^EQ[A-Za-z0-9_\-]{44,50}$"))
async def auto_scan(m: types.Message):
    await _scan(m, m.text.strip())


async def _scan(m: types.Message, address: str, deep: bool = False):
    msg = await m.answer(f"🔍 Scanning `{address[:18]}...`", parse_mode="Markdown")
    try:
        async with httpx.AsyncClient(timeout=20) as c:
            r = await c.post(f"{API}/api/scan", json={"address": address, "deep": deep})
            d = r.json()

        verdict = d.get("verdict", "UNKNOWN")
        score = d.get("risk_score", 0)
        flags = d.get("flags", [])
        rec = d.get("recommendation", "")
        icon = VERDICT_ICON.get(verdict, "⚪")

        text = (
            f"{icon} *{verdict}* — `{score}%`\n\n"
            f"Address: `{address}`\n"
            f"Balance: `{d.get('balance', 0):.4f} TON`\n"
            f"State: `{d.get('state', '?')}`\n"
            f"TXs: `{d.get('tx_count', 0)}`\n"
            f"Confidence: `{d.get('confidence', 'N/A')}`\n"
        )
        if flags:
            text += f"Flags: `{', '.join(flags)}`\n"
        text += f"\n{rec}"

        await msg.delete()
        await m.answer(text, parse_mode="Markdown", reply_markup=kb_scan(address))
    except Exception as e:
        await msg.edit_text(f"❌ Error: {e}")


async def start_bot():
    if not TOKEN:
        print("⚠️  TELEGRAM_BOT_TOKEN not set — bot disabled")
        return
    print("🤖 Telegram bot started")
    await dp.start_polling(bot)
