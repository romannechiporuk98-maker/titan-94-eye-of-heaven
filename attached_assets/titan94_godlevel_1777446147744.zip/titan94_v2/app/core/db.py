"""
TITAN-94 Database Layer
Auto-detects: PostgreSQL (production) or SQLite (Replit/local)
Uses aiosqlite for SQLite, asyncpg for PostgreSQL
"""
import os
import json
import asyncio
from datetime import datetime
from typing import List, Dict, Any, Optional
from pathlib import Path

DB_URL = os.getenv("DB_URL", "")
USE_POSTGRES = DB_URL.startswith("postgresql")

DATA_DIR = Path(__file__).parent.parent.parent / "data"
SQLITE_PATH = DATA_DIR / "titan94.db"


# ── SQLite backend (default for Replit) ──────────────────────────────────────

class SQLiteDB:
    def __init__(self):
        self._conn = None

    async def connect(self):
        import aiosqlite
        DATA_DIR.mkdir(parents=True, exist_ok=True)
        self._conn = await aiosqlite.connect(str(SQLITE_PATH))
        await self._conn.execute("PRAGMA journal_mode=WAL")

    async def init_tables(self):
        await self._conn.executescript("""
            CREATE TABLE IF NOT EXISTS scans (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                address TEXT NOT NULL,
                verdict TEXT,
                risk_score INTEGER,
                flags TEXT,
                tx_count INTEGER,
                payload TEXT,
                created_at TEXT DEFAULT (datetime('now'))
            );
            CREATE TABLE IF NOT EXISTS alerts (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                level TEXT,
                message TEXT,
                address TEXT,
                meta TEXT,
                created_at TEXT DEFAULT (datetime('now'))
            );
        """)
        await self._conn.commit()

    async def save_scan(self, data: Dict):
        await self._conn.execute(
            "INSERT INTO scans (address, verdict, risk_score, flags, tx_count, payload) VALUES (?,?,?,?,?,?)",
            (
                data.get("address", ""),
                data.get("verdict", "UNKNOWN"),
                data.get("risk_score", 0),
                json.dumps(data.get("flags", [])),
                data.get("tx_count", 0),
                json.dumps(data)
            )
        )
        await self._conn.commit()

    async def save_alert(self, data: Dict):
        await self._conn.execute(
            "INSERT INTO alerts (level, message, address, meta) VALUES (?,?,?,?)",
            (data.get("level"), data.get("message"), data.get("address"), json.dumps(data.get("meta", {})))
        )
        await self._conn.commit()

    async def get_history(self, limit: int = 30) -> List[Dict]:
        async with self._conn.execute(
            "SELECT address, verdict, risk_score, flags, tx_count, created_at FROM scans ORDER BY id DESC LIMIT ?",
            (limit,)
        ) as cur:
            rows = await cur.fetchall()
        return [
            {"address": r[0], "verdict": r[1], "risk_score": r[2],
             "flags": json.loads(r[3] or "[]"), "tx_count": r[4], "created_at": r[5]}
            for r in rows
        ]

    async def get_alerts(self, limit: int = 50) -> List[Dict]:
        async with self._conn.execute(
            "SELECT level, message, address, meta, created_at FROM alerts ORDER BY id DESC LIMIT ?",
            (limit,)
        ) as cur:
            rows = await cur.fetchall()
        return [
            {"level": r[0], "message": r[1], "address": r[2],
             "meta": json.loads(r[3] or "{}"), "created_at": r[4]}
            for r in rows
        ]

    async def get_stats(self) -> Dict:
        async with self._conn.execute("SELECT COUNT(*), verdict FROM scans GROUP BY verdict") as cur:
            rows = await cur.fetchall()
        counts = {r[1]: r[0] for r in rows}
        total = sum(counts.values())
        async with self._conn.execute("SELECT COUNT(*) FROM alerts") as cur:
            alert_count = (await cur.fetchone())[0]
        return {
            "total_scans": total,
            "honeypots": counts.get("HONEYPOT", 0),
            "suspicious": counts.get("SUSPICIOUS", 0),
            "caution": counts.get("CAUTION", 0),
            "safe": counts.get("SAFE", 0),
            "total_alerts": alert_count,
        }

    async def clear_history(self):
        await self._conn.execute("DELETE FROM scans")
        await self._conn.commit()


# ── PostgreSQL backend ────────────────────────────────────────────────────────

class PostgresDB:
    def __init__(self):
        self._pool = None

    async def connect(self):
        import asyncpg
        self._pool = await asyncpg.create_pool(DB_URL, min_size=2, max_size=10)

    async def init_tables(self):
        async with self._pool.acquire() as conn:
            await conn.execute("""
                CREATE TABLE IF NOT EXISTS scans (
                    id SERIAL PRIMARY KEY,
                    address TEXT NOT NULL,
                    verdict TEXT,
                    risk_score INTEGER,
                    flags JSONB DEFAULT '[]',
                    tx_count INTEGER DEFAULT 0,
                    payload JSONB DEFAULT '{}',
                    created_at TIMESTAMPTZ DEFAULT NOW()
                );
                CREATE TABLE IF NOT EXISTS alerts (
                    id SERIAL PRIMARY KEY,
                    level TEXT,
                    message TEXT,
                    address TEXT,
                    meta JSONB DEFAULT '{}',
                    created_at TIMESTAMPTZ DEFAULT NOW()
                );
            """)

    async def save_scan(self, data: Dict):
        async with self._pool.acquire() as conn:
            await conn.execute(
                "INSERT INTO scans (address, verdict, risk_score, flags, tx_count, payload) VALUES ($1,$2,$3,$4,$5,$6)",
                data.get("address", ""), data.get("verdict", "UNKNOWN"),
                data.get("risk_score", 0), json.dumps(data.get("flags", [])),
                data.get("tx_count", 0), json.dumps(data)
            )

    async def save_alert(self, data: Dict):
        async with self._pool.acquire() as conn:
            await conn.execute(
                "INSERT INTO alerts (level, message, address, meta) VALUES ($1,$2,$3,$4)",
                data.get("level"), data.get("message"),
                data.get("address"), json.dumps(data.get("meta", {}))
            )

    async def get_history(self, limit: int = 30) -> List[Dict]:
        async with self._pool.acquire() as conn:
            rows = await conn.fetch(
                "SELECT address, verdict, risk_score, flags::text, tx_count, created_at::text FROM scans ORDER BY id DESC LIMIT $1",
                limit
            )
        return [dict(r) for r in rows]

    async def get_alerts(self, limit: int = 50) -> List[Dict]:
        async with self._pool.acquire() as conn:
            rows = await conn.fetch(
                "SELECT level, message, address, meta::text, created_at::text FROM alerts ORDER BY id DESC LIMIT $1",
                limit
            )
        return [dict(r) for r in rows]

    async def get_stats(self) -> Dict:
        async with self._pool.acquire() as conn:
            rows = await conn.fetch("SELECT verdict, COUNT(*) FROM scans GROUP BY verdict")
            alert_count = await conn.fetchval("SELECT COUNT(*) FROM alerts")
        counts = {r["verdict"]: r["count"] for r in rows}
        return {
            "total_scans": sum(counts.values()),
            "honeypots": counts.get("HONEYPOT", 0),
            "suspicious": counts.get("SUSPICIOUS", 0),
            "caution": counts.get("CAUTION", 0),
            "safe": counts.get("SAFE", 0),
            "total_alerts": alert_count,
        }

    async def clear_history(self):
        async with self._pool.acquire() as conn:
            await conn.execute("DELETE FROM scans")


# ── Factory ───────────────────────────────────────────────────────────────────

db: Any = PostgresDB() if USE_POSTGRES else SQLiteDB()


async def init_db():
    await db.connect()
    await db.init_tables()
    print(f"💾 DB: {'PostgreSQL' if USE_POSTGRES else 'SQLite'}")
