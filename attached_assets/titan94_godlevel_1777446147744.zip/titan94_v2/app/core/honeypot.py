"""
TITAN-94 Honeypot & Risk Analysis Engine
Full multi-signal scoring for TON addresses
"""
import httpx
from typing import List, Dict, Any
from datetime import datetime

TONCENTER = "https://toncenter.com/api/v2"

RISK_FLAGS = {
    "no_outgoing":     40,
    "high_fee_ratio":  25,
    "zero_out_value":  20,
    "circular_flow":   30,
    "single_source":   20,
    "burst_txs":       15,
    "lure_comment":    10,
    "zero_balance":    35,
    "inactive":        10,
}

LURE_WORDS = ["airdrop","free","claim","bonus","reward","100x",
              "profit","invest","withdraw","urgent","double","giveaway"]


async def fetch_txs(address: str, limit: int = 15) -> List[Dict]:
    try:
        async with httpx.AsyncClient(timeout=10.0) as c:
            r = await c.get(f"{TONCENTER}/getTransactions",
                           params={"address": address, "limit": limit})
            data = r.json()
            if not data.get("ok"):
                return []
            return [_parse(tx) for tx in data.get("result", [])]
    except Exception as e:
        return [{"error": str(e)}]


async def fetch_info(address: str) -> Dict:
    try:
        async with httpx.AsyncClient(timeout=10.0) as c:
            r = await c.get(f"{TONCENTER}/getAddressInformation",
                           params={"address": address})
            data = r.json()
            if not data.get("ok"):
                return {}
            res = data.get("result", {})
            return {
                "balance": int(res.get("balance", 0)) / 1e9,
                "state": res.get("state", "unknown"),
            }
    except Exception:
        return {}


async def analyze_address(address: str, deep: bool = False) -> Dict:
    """Main entry point — fetch + score"""
    limit = 25 if deep else 15
    txs, info = await _gather(address, limit)
    return score(address, txs, info)


async def _gather(address, limit):
    import asyncio
    return await asyncio.gather(fetch_txs(address, limit), fetch_info(address))


def score(address: str, txs: List[Dict], info: Dict) -> Dict:
    flags = []
    risk = 0

    if not txs or (len(txs) == 1 and "error" in txs[0]):
        return _build(address, 0, ["fetch_error"], txs, info, "UNKNOWN")

    total_in = sum(t.get("in_value", 0) for t in txs)
    total_out_msgs = sum(t.get("out_count", 0) for t in txs)
    total_out_val = sum(sum(t.get("out_values", [])) for t in txs)

    # No outgoing
    if total_out_msgs == 0 and len(txs) > 2:
        flags.append("no_outgoing"); risk += RISK_FLAGS["no_outgoing"]

    # High fee ratio
    for t in txs:
        if t.get("in_value", 0) > 0 and t.get("fee", 0) / t["in_value"] > 0.3:
            flags.append("high_fee_ratio"); risk += RISK_FLAGS["high_fee_ratio"]; break

    # Zero out values
    all_out = [v for t in txs for v in t.get("out_values", [])]
    if all_out and all(v == 0 for v in all_out):
        flags.append("zero_out_value"); risk += RISK_FLAGS["zero_out_value"]

    # Circular flow
    for t in txs:
        if t.get("from") and t.get("from") == t.get("to"):
            flags.append("circular_flow"); risk += RISK_FLAGS["circular_flow"]; break

    # Single source
    senders = [t["from"] for t in txs if t.get("from")]
    if senders and len(set(senders)) == 1 and len(senders) >= 3:
        flags.append("single_source"); risk += RISK_FLAGS["single_source"]

    # Burst
    times = [t["time"][:16] for t in txs if t.get("time")]
    if len(times) >= 3 and len(set(times)) == 1:
        flags.append("burst_txs"); risk += RISK_FLAGS["burst_txs"]

    # Lure comment
    for t in txs:
        if any(w in t.get("comment", "").lower() for w in LURE_WORDS):
            flags.append("lure_comment"); risk += RISK_FLAGS["lure_comment"]; break

    # Zero balance (from info)
    if info.get("balance", 1) == 0 and total_in > 0:
        flags.append("zero_balance"); risk += RISK_FLAGS["zero_balance"]

    risk = min(risk, 100)
    flags = list(set(flags))
    return _build(address, risk, flags, txs, info, _verdict(risk))


def _build(address, risk, flags, txs, info, verdict) -> Dict:
    total_in = sum(t.get("in_value", 0) for t in txs if "error" not in t)
    total_out = sum(sum(t.get("out_values", [])) for t in txs if "error" not in t)
    return {
        "address": address,
        "risk_score": risk,
        "verdict": verdict,
        "flags": flags,
        "tx_count": len([t for t in txs if "error" not in t]),
        "total_in": round(total_in, 6),
        "total_out": round(total_out, 6),
        "balance": info.get("balance", 0),
        "state": info.get("state", "unknown"),
        "timestamp": datetime.utcnow().isoformat(),
    }


def _verdict(score: int) -> str:
    if score >= 70: return "HONEYPOT"
    if score >= 45: return "SUSPICIOUS"
    if score >= 20: return "CAUTION"
    return "SAFE"


def _parse(tx: Dict) -> Dict:
    in_msg = tx.get("in_msg", {})
    out_msgs = tx.get("out_msgs", [])
    return {
        "hash": tx.get("transaction_id", {}).get("hash", ""),
        "time": datetime.utcfromtimestamp(tx.get("utime", 0)).isoformat(),
        "fee": int(tx.get("fee", 0)) / 1e9,
        "in_value": int(in_msg.get("value", 0)) / 1e9,
        "out_count": len(out_msgs),
        "out_values": [int(m.get("value", 0)) / 1e9 for m in out_msgs],
        "from": in_msg.get("source", ""),
        "to": in_msg.get("destination", ""),
        "comment": _comment(in_msg),
    }


def _comment(msg: Dict) -> str:
    try:
        body = msg.get("msg_data", {})
        if body.get("@type") == "msg.dataText":
            return body.get("text", "")
    except Exception:
        pass
    return ""
