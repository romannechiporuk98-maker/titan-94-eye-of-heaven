"""
TITAN-94 TON Live Stream
Continuously polls TON network for transactions and auto-scans addresses
"""
import asyncio
import httpx
import os
from datetime import datetime
from app.ws.server import ws_manager

TONCENTER = "https://toncenter.com/api/v2"
POLL_INTERVAL = int(os.getenv("STREAM_INTERVAL", "8"))

# Watch list — add addresses to monitor 24/7
WATCH_LIST = os.getenv("WATCH_ADDRESSES", "").split(",")
WATCH_LIST = [a.strip() for a in WATCH_LIST if a.strip()]

stream_state = {
    "running": False,
    "last_tick": None,
    "ticks": 0,
    "addresses_seen": 0,
}


class TONStream:
    def __init__(self):
        self._seen: set = set()

    async def run(self):
        stream_state["running"] = True
        print(f"🌊 TON Stream started | interval={POLL_INTERVAL}s | watching={len(WATCH_LIST)}")
        while True:
            try:
                await self._tick()
            except Exception as e:
                print(f"[stream] error: {e}")
            await asyncio.sleep(POLL_INTERVAL)

    async def _tick(self):
        stream_state["ticks"] += 1
        stream_state["last_tick"] = datetime.utcnow().isoformat()

        # Broadcast heartbeat to dashboard
        await ws_manager.broadcast({
            "type": "heartbeat",
            "ticks": stream_state["ticks"],
            "ts": stream_state["last_tick"],
            "watching": len(WATCH_LIST),
        })

        if not WATCH_LIST:
            return

        tasks = [self._check_address(addr) for addr in WATCH_LIST]
        await asyncio.gather(*tasks, return_exceptions=True)

    async def _check_address(self, address: str):
        try:
            async with httpx.AsyncClient(timeout=8.0) as c:
                r = await c.get(
                    f"{TONCENTER}/getTransactions",
                    params={"address": address, "limit": 3}
                )
                data = r.json()
                if not data.get("ok"):
                    return

                txs = data.get("result", [])
                for tx in txs:
                    tx_hash = tx.get("transaction_id", {}).get("hash", "")
                    if tx_hash and tx_hash not in self._seen:
                        self._seen.add(tx_hash)
                        stream_state["addresses_seen"] += 1

                        # Auto-trigger scan on new tx
                        from app.core.honeypot import score, _parse, fetch_info
                        info = await fetch_info(address)
                        parsed = [_parse(t) for t in txs]
                        result = score(address, parsed, info)

                        # Broadcast live event
                        await ws_manager.broadcast({
                            "type": "live_tx",
                            "address": address,
                            "hash": tx_hash[:16] + "...",
                            "verdict": result["verdict"],
                            "risk_score": result["risk_score"],
                            "ts": datetime.utcnow().isoformat(),
                        })

                        # Auto-save to DB if suspicious
                        if result["risk_score"] >= 20:
                            from app.core.db import db
                            await db.save_scan(result)
                            if result["risk_score"] >= 45:
                                await db.save_alert({
                                    "level": "CRITICAL" if result["risk_score"] >= 70 else "WARN",
                                    "message": f"Auto-detected: {result['verdict']} — {address[:20]}...",
                                    "address": address,
                                    "meta": {"flags": result["flags"]}
                                })
                        break  # only process first new tx per poll
        except Exception as e:
            pass
