"""
TITAN-94 WebSocket Server
Real-time push to dashboard clients
"""
import asyncio
import json
from datetime import datetime
from typing import Set, Dict, Any
from fastapi import WebSocket


class WSManager:
    """Manages all active WebSocket connections"""

    def __init__(self):
        self._clients: Set[WebSocket] = set()
        self._message_count = 0

    async def connect(self, ws: WebSocket):
        await ws.accept()
        self._clients.add(ws)
        # Send welcome
        await ws.send_json({
            "type": "connected",
            "clients": len(self._clients),
            "ts": datetime.utcnow().isoformat()
        })
        print(f"[ws] +client  total={len(self._clients)}")

    def disconnect(self, ws: WebSocket):
        self._clients.discard(ws)
        print(f"[ws] -client  total={len(self._clients)}")

    async def broadcast(self, data: Dict[str, Any]):
        if not self._clients:
            return
        self._message_count += 1
        dead = set()
        for ws in self._clients.copy():
            try:
                await ws.send_json(data)
            except Exception:
                dead.add(ws)
        for ws in dead:
            self._clients.discard(ws)

    @property
    def count(self) -> int:
        return len(self._clients)


ws_manager = WSManager()


async def ws_broadcast_loop():
    """Periodically push system status to all clients"""
    print("📡 WebSocket broadcast loop running")
    while True:
        await asyncio.sleep(5)
        if ws_manager.count > 0:
            await ws_manager.broadcast({
                "type": "ping",
                "clients": ws_manager.count,
                "ts": datetime.utcnow().isoformat(),
            })
