"""
TITAN-94 Multi-Agent Fusion Engine
4 specialized agents → consensus verdict
"""
from typing import Dict, List, Any
from datetime import datetime


class Agent:
    name = "base"

    def run(self, data: Dict) -> Dict:
        return {"agent": self.name, "score": 0, "signals": []}


class VolumeAgent(Agent):
    name = "volume"

    def run(self, data: Dict) -> Dict:
        total_in = data.get("total_in", 0)
        total_out = data.get("total_out", 0)
        ratio = total_out / total_in if total_in > 0 else 0
        score = 0
        signals = []
        if total_in > 0 and ratio < 0.05:
            score = 60; signals.append("near_zero_outflow")
        elif ratio < 0.3:
            score = 30; signals.append("low_outflow")
        return {"agent": self.name, "score": score, "flow_ratio": round(ratio, 4), "signals": signals}


class PatternAgent(Agent):
    name = "pattern"

    def run(self, data: Dict) -> Dict:
        flags = data.get("flags", [])
        HIGH_WEIGHT = {"no_outgoing", "zero_balance", "circular_flow"}
        score = sum(20 if f in HIGH_WEIGHT else 10 for f in flags)
        return {"agent": self.name, "score": min(score, 100), "flags": flags, "signals": flags}


class ReputationAgent(Agent):
    name = "reputation"

    # Known risky address prefixes (expand with real intel)
    RISKY = ["EQD9", "EQC4", "EQBK"]

    def run(self, data: Dict) -> Dict:
        addr = data.get("address", "")
        score = 0
        signals = []
        for prefix in self.RISKY:
            if addr.startswith(prefix):
                score += 15
                signals.append(f"risky_prefix:{prefix}")
        # Inactive contract with incoming funds = suspicious
        if data.get("state") == "uninitialized" and data.get("total_in", 0) > 0:
            score += 25; signals.append("uninitialized_with_funds")
        return {"agent": self.name, "score": min(score, 100), "signals": signals}


class BehaviourAgent(Agent):
    name = "behaviour"

    def run(self, data: Dict) -> Dict:
        tx_count = data.get("tx_count", 0)
        score = 0
        signals = []
        if tx_count == 0:
            score = 15; signals.append("no_tx_history")
        elif tx_count >= 50:
            score = 5; signals.append("high_activity_ok")
        return {"agent": self.name, "score": score, "signals": signals}


class FusionEngine:
    def __init__(self):
        self.agents = [VolumeAgent(), PatternAgent(), ReputationAgent(), BehaviourAgent()]

    async def analyze(self, address: str, base: Dict) -> Dict:
        base["address"] = address
        results = [a.run(base) for a in self.agents]

        agent_scores = [r["score"] for r in results]
        agent_avg = sum(agent_scores) / len(agent_scores)
        honeypot_score = base.get("risk_score", 0)

        # Weighted: 55% honeypot engine, 45% agents
        final = int(honeypot_score * 0.55 + agent_avg * 0.45)
        final = min(final, 100)

        verdict = self._verdict(final)
        base.update({
            "risk_score": final,
            "verdict": verdict,
            "confidence": self._confidence(results),
            "recommendation": self._rec(verdict),
            "agents": results,
            "timestamp": datetime.utcnow().isoformat(),
        })
        return base

    def _verdict(self, s):
        if s >= 70: return "HONEYPOT"
        if s >= 45: return "SUSPICIOUS"
        if s >= 20: return "CAUTION"
        return "SAFE"

    def _confidence(self, results):
        hot = sum(1 for r in results if r["score"] > 0)
        return "HIGH" if hot >= 3 else "MEDIUM" if hot >= 2 else "LOW"

    def _rec(self, v):
        return {
            "HONEYPOT":   "⛔ DO NOT INTERACT — high probability of fund loss",
            "SUSPICIOUS": "⚠️  Extreme caution — verify on-chain independently",
            "CAUTION":    "🟡 Some risk signals — research before transacting",
            "SAFE":       "✅ No major risk signals detected",
        }.get(v, "Unknown")
