"""
TITAN-94 FastAPI Application
Routes: scan, stream, history, stats, alerts, websocket
"""
from fastapi import FastAPI, HTTPException, WebSocket, WebSocketDisconnect
from fastapi.staticfiles import StaticFiles
from fastapi.responses import HTMLResponse, FileResponse
from pydantic import BaseModel
from typing import Optional, List
import pathlib
import asyncio

from app.core.db import db
from app.core.honeypot import analyze_address
from app.agents.agents import FusionEngine
from app.ws.server import ws_manager

app = FastAPI(title="TITAN-94", version="4.0.0-GODLEVEL")

DASH = pathlib.Path(__file__).parent.parent / "dashboard"
if DASH.exists():
    app.mount("/static", StaticFiles(directory=str(DASH)), name="static")

fusion = FusionEngine()


# ── Startup ──────────────────────────────────────────────────────────────────

@app.on_event("startup")
async def startup():
    from app.core.db import init_db
    await init_db()
    print("✅ DB initialized")


# ── Models ────────────────────────────────────────────────────────────────────

class ScanReq(BaseModel):
    address: str
    deep: Optional[bool] = False


class AlertReq(BaseModel):
    level: str  # INFO | WARN | CRITICAL
    message: str
    address: Optional[str] = None
    meta: Optional[dict] = {}


# ── Routes ────────────────────────────────────────────────────────────────────

@app.get("/", response_class=HTMLResponse)
async def dashboard():
    f = DASH / "index.html"
    return FileResponse(str(f)) if f.exists() else HTMLResponse("<h1>TITAN-94</h1>")


@app.get("/health")
async def health():
    stats = await db.get_stats()
    return {"status": "online", "version": "4.0.0-GODLEVEL", "stats": stats}


@app.post("/api/scan")
async def scan(req: ScanReq):
    try:
        result = await analyze_address(req.address, deep=req.deep)
        result = await fusion.analyze(req.address, result)
        await db.save_scan(result)

        # Broadcast to all WS clients
        await ws_manager.broadcast({
            "type": "scan",
            "address": req.address,
            "verdict": result["verdict"],
            "risk_score": result["risk_score"]
        })

        return result
    except Exception as e:
        raise HTTPException(500, str(e))


@app.get("/api/scan/{address}")
async def scan_get(address: str):
    return await scan(ScanReq(address=address))


@app.get("/api/history")
async def history(limit: int = 30):
    return {"history": await db.get_history(limit)}


@app.get("/api/stats")
async def stats():
    return await db.get_stats()


@app.post("/api/alert")
async def create_alert(req: AlertReq):
    await db.save_alert(req.dict())
    await ws_manager.broadcast({"type": "alert", **req.dict()})
    return {"status": "ok"}


@app.get("/api/alerts")
async def get_alerts(limit: int = 50):
    return {"alerts": await db.get_alerts(limit)}


@app.delete("/api/history")
async def clear():
    await db.clear_history()
    return {"status": "cleared"}


@app.get("/api/stream/status")
async def stream_status():
    from app.ton.stream import stream_state
    return stream_state


# ── WebSocket ─────────────────────────────────────────────────────────────────

@app.websocket("/ws")
async def websocket_endpoint(ws: WebSocket):
    await ws_manager.connect(ws)
    try:
        while True:
            data = await ws.receive_text()
            # Echo commands back
            await ws.send_json({"type": "ack", "data": data})
    except WebSocketDisconnect:
        ws_manager.disconnect(ws)
