"""
TITAN-94 Telegram Bot
Full implementation with all commands
"""
import os
import asyncio
import aiohttp
from aiogram import Bot, Dispatcher, types, F
from aiogram.filters import Command
from aiogram.types import InlineKeyboardMarkup, InlineKeyboardButton, WebAppInfo
from dotenv import load_dotenv

load_dotenv()

TOKEN = os.getenv("TELEGRAM_BOT_TOKEN", "")
API_URL = os.getenv("API_BASE_URL", "http://localhost:8000")
TMA_URL = os.getenv("TITAN_MINI_APP_URL", "http://localhost:8000")
ADMIN_ID = int(os.getenv("ADMIN_TELEGRAM_ID", "7255058720"))

bot = Bot(token=TOKEN) if TOKEN else None
dp = Dispatcher()

# ── Keyboards ─────────────────────────────────────────────────
def main_kb():
    return InlineKeyboardMarkup(inline_keyboard=[
        [InlineKeyboardButton(
            text="🛡 OPEN TITAN DASHBOARD",
            web_app=WebAppInfo(url=TMA_URL)
        )],
        [
            InlineKeyboardButton(text="🔍 Scan", callback_data="scan"),
            InlineKeyboardButton(text="📊 Stats", callback_data="stats"),
            InlineKeyboardButton(text="🛡 Threats", callback_data="threats"),
        ],
        [
            InlineKeyboardButton(text="💰 Plans", callback_data="plans"),
            InlineKeyboardButton(text="❓ Help", callback_data="help"),
        ],
    ])

# ── API Helper ─────────────────────────────────────────────────
async def api_get(path):
    async with aiohttp.ClientSession() as s:
        async with s.get(f"{API_URL}{path}") as r:
            return await r.json()

async def api_post(path, data):
    async with aiohttp.ClientSession() as s:
        async with s.post(f"{API_URL}{path}", json=data) as r:
            return await r.json()

# ── Commands ───────────────────────────────────────────────────

@dp.message(Command("start"))
async def cmd_start(m: types.Message):
    text = """
🛡 **TITAN-94 «ОКО НЕБЕСНЕ»**
_Solo Deo Subjectus · DEI GRATIA_

Автономний AI-організм безпеки TON блокчейну.

**Функціональність:**
🔍 Сканування адрес
🍯 Honeypot детектор
⚡ Арбітраж сигнали
📊 Статистика ринку
🧬 Genesis AI

Натисни кнопку нижче щоб відкрити TITAN Terminal!
"""
    await m.answer(text, parse_mode="Markdown", reply_markup=main_kb())

@dp.message(Command("scan"))
async def cmd_scan(m: types.Message):
    parts = m.text.split(maxsplit=1)
    if len(parts) < 2:
        return await m.answer("Usage: `/scan EQ...`", parse_mode="Markdown")

    address = parts[1].strip()
    msg = await m.answer(f"🔍 Scanning `{address[:30]}...`", parse_mode="Markdown")

    try:
        result = await api_post("/api/scan", {"address": address})
        score = result.get("final_score", 0)
        level = result.get("level", "UNKNOWN")
        icon = {"HONEYPOT": "🔴", "SUSPICIOUS": "🟠", "CAUTION": "🟡", "SAFE": "🟢"}.get(level, "⚪")

        text = f"""
{icon} **{level}** – {score}/100

**Address:** `{address}`
**Flags:** {', '.join(result.get('active_flags', []))}
**AI Analysis:** {result.get('ai_analysis', '')[:200]}
"""
        await msg.edit_text(text, parse_mode="Markdown")
    except Exception as e:
        await msg.edit_text(f"❌ Error: {e}")

@dp.message(Command("stats"))
async def cmd_stats(m: types.Message):
    try:
        stats = await api_get("/api/stats")
        text = f"""
📊 **TITAN-94 Statistics**

Total scans: **{stats.get('total_scans', 0)}**
Status: **ONLINE ✅**
Version: **4.0.0**
"""
        await m.answer(text, parse_mode="Markdown")
    except Exception as e:
        await m.answer(f"❌ Error: {e}")

@dp.message(Command("help"))
async def cmd_help(m: types.Message):
    text = """
**TITAN-94 Bot Commands:**

/start – Menu
/scan {address} – Scan TON address
/stats – System stats
/threat – Active threats
/plans – Subscription plans
/help – This message

**Web App:**
Tap 🛡 OPEN TITAN DASHBOARD for full features!
"""
    await m.answer(text, parse_mode="Markdown")

# ── Callbacks ─────────────────────────────────────────────────
@dp.callback_query(F.data == "scan")
async def cb_scan(cb: types.CallbackQuery):
    await cb.answer()
    await cb.message.answer("Send TON address (EQxxx...)")

@dp.callback_query(F.data == "stats")
async def cb_stats(cb: types.CallbackQuery):
    await cb.answer()
    await cmd_stats(cb.message)

@dp.callback_query(F.data == "threats")
async def cb_threats(cb: types.CallbackQuery):
    await cb.answer()
    await cb.message.answer("Check dashboard for active threats", reply_markup=InlineKeyboardMarkup(
        inline_keyboard=[[InlineKeyboardButton(text="🛡 Open Dashboard", web_app=WebAppInfo(url=TMA_URL))]]
    ))

@dp.callback_query(F.data == "plans")
async def cb_plans(cb: types.CallbackQuery):
    await cb.answer()
    text = """
📋 **TITAN-94 Plans**

FREE – Basic scan
PRO – 5 TON/mo – Unlimited + AI
ELITE – 20 TON/mo – All + Arbitrage + API
"""
    await cb.message.answer(text, parse_mode="Markdown")

@dp.callback_query(F.data == "help")
async def cb_help(cb: types.CallbackQuery):
    await cb.answer()
    await cmd_help(cb.message)

# ── Auto-scan addresses ────────────────────────────────────────
@dp.message(F.text.regexp(r"^EQ[A-Za-z0-9_\-]{44,50}$"))
async def auto_scan(m: types.Message):
    await cmd_scan(types.Message(text=f"/scan {m.text}"))

async def start_bot():
    if not TOKEN:
        print("⚠️  TELEGRAM_BOT_TOKEN not set")
        return
    print("🤖 Telegram Bot started")
    await dp.start_polling(bot)

if __name__ == "__main__":
    asyncio.run(start_bot())
