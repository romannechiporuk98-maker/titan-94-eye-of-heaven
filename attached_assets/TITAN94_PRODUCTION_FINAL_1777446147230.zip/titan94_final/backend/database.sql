"""
TITAN-94 Database Schema
PostgreSQL 14+
"""

CREATE TABLE IF NOT EXISTS scans (
    id SERIAL PRIMARY KEY,
    address VARCHAR(100) NOT NULL UNIQUE,
    score INT CHECK (score >= 0 AND score <= 100),
    level VARCHAR(20) DEFAULT 'SAFE',
    data JSONB NOT NULL,
    created_at TIMESTAMP DEFAULT NOW(),
    updated_at TIMESTAMP DEFAULT NOW()
);

CREATE TABLE IF NOT EXISTS alerts (
    id SERIAL PRIMARY KEY,
    scan_id INT REFERENCES scans(id) ON DELETE CASCADE,
    alert_type VARCHAR(50),
    message TEXT,
    severity VARCHAR(20),
    sent_at TIMESTAMP DEFAULT NOW()
);

CREATE TABLE IF NOT EXISTS activity (
    id SERIAL PRIMARY KEY,
    type VARCHAR(50),
    message TEXT,
    severity VARCHAR(20) DEFAULT 'info',
    metadata JSONB,
    created_at TIMESTAMP DEFAULT NOW()
);

CREATE TABLE IF NOT EXISTS subscribers (
    id SERIAL PRIMARY KEY,
    telegram_id VARCHAR(50) UNIQUE,
    plan VARCHAR(20) DEFAULT 'free',
    expires_at TIMESTAMP,
    is_active BOOLEAN DEFAULT true,
    created_at TIMESTAMP DEFAULT NOW()
);

CREATE TABLE IF NOT EXISTS blocked_addresses (
    id SERIAL PRIMARY KEY,
    address VARCHAR(100) UNIQUE NOT NULL,
    reason TEXT,
    severity VARCHAR(20),
    blocked_at TIMESTAMP DEFAULT NOW()
);

CREATE INDEX idx_scans_address ON scans(address);
CREATE INDEX idx_scans_level ON scans(level);
CREATE INDEX idx_scans_created ON scans(created_at DESC);
CREATE INDEX idx_activity_type ON activity(type);
