# TITAN-94 «ОКО НЕБЕСНЕ» — COMPLETE PRODUCTION GUIDE

## OVERVIEW

**TITAN-94** is a fully autonomous AI security system for TON blockchain that:
- Scans addresses for honeypot & scam risks in real-time
- Uses multi-agent AI fusion (Gemini 2.5 + TON)
- Detects rug pulls, fake tokens, hidden restrictions
- Integrates with Telegram bot & Web App (TMA)
- Monetizes via subscriptions (Free/PRO/ELITE)

---

## ARCHITECTURE (7 LAYERS)

### LAYER 1: INPUT
- TON blockchain (TonCenter API)
- DEX pools (STON.fi, DeDust)
- Telegram Bot
- Web App (TMA)

### LAYER 2: NORMALIZATION
Standardize raw data into unified format with timestamp

### LAYER 3: EVENT BUS
Redis queue for async processing. Enables scalability.

### LAYER 4: HONEYPOT DETECTOR
8 specialized rules for scam detection:
- `no_outgoing` (40pts) — No sell transactions
- `high_fee` (25pts) — Fee > 20%
- `zero_out_value` (20pts) — Outputs worth 0
- `circular_flow` (30pts) — Circular transfers
- `single_source` (20pts) — Only from 1 wallet
- `burst_txs` (15pts) — Sudden spike
- `lure_comment` (10pts) — Suspicious memo
- `zero_balance` (35pts) — Balance emptied

Score > 70 = HONEYPOT
Score 45-70 = SUSPICIOUS
Score 20-45 = CAUTION
Score < 20 = SAFE

### LAYER 5: AI CORE
**Gemini 2.5** models for deep analysis:
- Pattern recognition
- Liquidity tracking
- Risk factor weighting
- Narrative generation

### LAYER 6: FUSION ENGINE
Combine signals: 55% Honeypot Detector + 45% AI = Final Risk Score

### LAYER 7: ACTION
- Database logging
- Telegram alerts
- Web API response
- Cache update (Redis)

---

## TECH STACK

**Backend:**
- FastAPI (Python)
- PostgreSQL (data)
- Redis (queue)
- Docker (deploy)

**Frontend:**
- React/Vite
- Tailwind CSS
- TON Connect 2.0

**Bot:**
- aiogram 3 (Telegram)
- asyncio (async)

**AI:**
- Google Gemini 2.5
- TonCenter API v2

---

## QUICK START

### 1. Clone & Setup
```bash
git clone https://github.com/titanagent/titan94.git
cd titan94
cp .env.example .env
# Fill in GEMINI_API_KEY, TELEGRAM_BOT_TOKEN, etc.
```

### 2. Docker Compose
```bash
docker-compose up -d
# Services: postgres, redis, api, bot
```

### 3. Database Init
```bash
psql postgresql://titan:changeme123@localhost:5432/titan94 < backend/database.sql
```

### 4. Test API
```bash
curl http://localhost:8000/health
curl -X POST http://localhost:8000/api/scan \
  -H "Content-Type: application/json" \
  -d '{"address":"EQCBdxpECK7MofzA"}'
```

### 5. Bot
- Open Telegram, search `@Titan_94_agent_bot`
- `/start` → full menu
- `/scan EQ...` → inline scan

### 6. Web App (TMA)
- Open dashboard at `http://localhost:8000`
- Connect wallet via TON Connect 2.0
- Full UI with stats, history, monitoring

---

## API ENDPOINTS (24 routes)

### Scan
- `POST /api/scan` — Full analysis
- `GET /api/scan/{address}` — Cached result

### History
- `GET /api/history` — Scan history
- `GET /api/stats` — Aggregated stats

### Real-time
- `WebSocket /ws` — Live updates

### Admin
- `GET /health` — System health
- `POST /api/event` — Push custom event

---

## HONEYPOT LOGIC (CORE)

```python
def detect_honeypot(address):
    score = 0
    
    # Rule 1: No outgoing TXs (strongest)
    if no_sell_transactions(address):
        score += 40
    
    # Rule 2: Single source (ping-pong)
    if only_from_one_wallet(address):
        score += 20
    
    # Rule 3: High frequency, no sells (pump prep)
    if burst_txs_and_no_sells(address):
        score += 15
    
    # Rule 4: Emptied balance
    if balance < 0.001:
        score += 35
    
    return {
        "is_honeypot": score > 70,
        "probability": min(100, score) / 100,
        "active_flags": [...]
    }
```

---

## MONETIZATION

### Plans

**Free**
- 5 scans/day
- Activity feed
- 72h PRO trial

**PRO — 5 TON/month**
- Unlimited scans
- AI analysis
- HoneyPot detector
- Real-time alerts

**ELITE — 20 TON/month**
- All PRO features
- Arbitrage signals
- API access
- Whale alerts
- Priority support

### Revenue Model
- Subscription (primary)
- API licensing (B2B)
- Affiliate commissions
- Bounties for discoveries

---

## DEPLOYMENT (PRODUCTION)

### Railway / Replit
```bash
# 1. Connect Git repo
# 2. Set environment variables
# 3. Deploy docker-compose
```

### Self-Hosted
```bash
# 1. VPS (Ubuntu 22+)
# 2. Install Docker
# 3. docker-compose up -d
# 4. nginx reverse proxy
# 5. SSL certificate
```

### Scaling
- PostgreSQL replication
- Redis cluster
- Load balancer (nginx)
- CDN for static assets

---

## COMMANDS (ALL)

### Bot
- `/start` — Menu
- `/scan EQ...` — Scan address
- `/stats` — Stats
- `/help` — Help
- `/threats` — Active threats
- `/market` — Arbitrage signals
- `/wallet` — Reserve fund
- `/plans` — Subscribe

### Admin
- `/heal` — Genesis evolution
- `/dev` — Developer agent
- `/promote` — Promoter agent
- `/broadcast` — Send message

---

## FUTURE ROADMAP

v5.0
- Multi-chain (Ethereum, Solana)
- DEX aggregator
- ML-based pattern learning
- Mobile app (iOS/Android)

v6.0
- DAO governance
- Bounty hunters program
- Security insurance
- Enterprise API

---

## SUPPORT

- GitHub: https://github.com/titanagent/titan94
- Telegram: @Titan_94_agent_bot
- Email: security@titan94.org
- Docs: https://docs.titan94.org

---

## LICENSE

MIT License — Open Source

---

**TITAN-94 — Securing TON, One Address at a Time.**

*Solo Deo Subjectus · DEI GRATIA*

*Version 4.0.0 · 2026*
