# TITAN 94

Full AI + Web3 Security System

Run:
pip install -r requirements.txt
uvicorn app.main:app --host 0.0.0.0 --port 8000
